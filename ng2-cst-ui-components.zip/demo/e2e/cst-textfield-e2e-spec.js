describe('UI Automation Tests: CSTTextfieldComponent', function() {
  "use strict";
   
   //opening broweser only once for all test cases
   browser.get(process.env.UI_APP_URL || 'http://localhost:3000', 18000000);
   browser.waitForAngular();

  describe('UI Automation Tests: CSTTextfieldComponent_01', function() {
   
   let csttextfield_01 = element(by.css('cst-textfield [ placeholder="Placeholder text"]'));
   // let previous_input = element(by.css('cst-textfield .value-change-container'));
   // let label = element(by.css('cst-textfield div label')); 
   
   let btn_ctx_menu = element(by.id('float_menu'));
   let elements = element.all(protractor.By.css('.menu .showMenu'));
 
   beforeEach(() => {
    csttextfield_01.clear();
  });


  it('should click Textfield from float menu', () => {

    console.log('\t Hovering the mouse on float menu');
    browser.actions().mouseMove(btn_ctx_menu).perform();
    browser.driver.sleep(1000);

    console.log("\tClicking over the context menu");
    browser.wait(btn_ctx_menu.click().then(function() {
    browser.driver.sleep(1000);  
      console.log('\tClicking over the textfield');
    elements.get(0).click().then(function() {
    browser.driver.sleep(1000); 
      }, 120);
    }))
  });

  it('Should able to click on the text field',() => {

    console.log("\t1.0. Should click on the text field");
    browser.wait(csttextfield_01.click().then(function() { 
    browser.driver.sleep(2000); 
    }),500);
  });
  
  it('Should send key into text field and clear key',() => {
 
    console.log("\t2.0. Should send key into text field and clear key");
   'SendandClear-Key-Test'.split('').forEach((c) => csttextfield_01.sendKeys(c));
    browser.driver.sleep(1000);
    csttextfield_01.getAttribute('value').then(function(inputValue) {
     expect(inputValue).toEqual('SendandClear-Key-Test');
    });
   
    browser.driver.sleep(1000);
    csttextfield_01.clear();
    browser.driver.sleep(1000);
  });

  it('Should select and unselect text', () => {
  
    console.log("\t3.0. Should select text and unselect text");
    csttextfield_01.click();
    browser.driver.sleep(1000);
    'Select-Text-Test'.split('').forEach((c) => csttextfield_01.sendKeys(c));

    browser.driver.sleep(500);
    csttextfield_01.getAttribute('value').then(function(inputValue) {
       //console.log(inputValue);
    });
     
    browser.driver.sleep(1000);
    csttextfield_01.sendKeys(protractor.Key.CONTROL, "a");
    browser.driver.sleep(1000);  

    var highlightedText = browser.executeScript(function getSelectionText()       
      {         
           return window.getSelection().toString(); 
      });
    expect(highlightedText).toEqual('Select-Text-Test');

    browser.driver.sleep(1000); 
    csttextfield_01.click();
    browser.driver.sleep(1000); 
  });

  it('Should delete the text', () => {
   
      console.log("\t4.0. Should delete the text"); 
     'Back-Space-Test'.split('').forEach((c) => csttextfield_01.sendKeys(c));

     csttextfield_01.getAttribute('value').then(function(inputValue) {
       expect(inputValue).toEqual('Back-Space-Test');
      });

     csttextfield_01.sendKeys(protractor.Key.BACK_SPACE);
     browser.driver.sleep(500);
     csttextfield_01.getAttribute('value').then(function(inputValue) {
       expect(inputValue).toEqual('Back-Space-Tes');
      });
   
       for (let i = 0; i < 4; i++) { 
           browser.driver.sleep(500);
            csttextfield_01.sendKeys(protractor.Key.BACK_SPACE);
        }
  });

  it('should click/unclick the Tooltip ', () => {

    console.log("\t5.0. should click/unclick the Tooltip of textfield_01"); 
   // let input = element(by.css('cst-textfield [ placeholder="Placeholder text"]'));
    let tooltipImg_01 = element(by.css('#dashboard_csttextfield_01 div div label cst-tooltip span div.tooltip-icon'));
    browser.actions().mouseMove(csttextfield_01).perform();
    browser.driver.sleep(1000);

    browser.wait(tooltipImg_01.click().then(function() { 

    browser.driver.sleep(1000); // timeout to check the above operation with naked eye!
    }),2000);

     tooltipImg_01.click();
     browser.driver.sleep(500)
  });
});



describe('UI Automation Tests: CSTTextfieldComponent_02', function() {

  let csttextfield_02 = element(by.css('cst-textfield [ placeholder="Placeholder text 1"]'));
  let tooltipImg_02 = element(by.css('#dashboard_csttextfield_02 div div label cst-tooltip span div.tooltip-icon'));

  it('should click/unclick the Tooltip ', () => {

    console.log("\t1.0. should click/unclick the Tooltip of textfield_02"); 
    
    browser.actions().mouseMove(csttextfield_02).perform();
    browser.driver.sleep(2000);

    browser.wait(tooltipImg_02.click().then(function() { 

    browser.driver.sleep(3000); // timeout to check the above operation with naked eye!
    }),5000);

     tooltipImg_02.click();
     browser.driver.sleep(3000)
  });


});

describe('UI Automation Tests: CSTTextfieldComponent_03', function() {
   
   
   let csttextfield_03 = element(by.css('cst-textfield [ placeholder="Placeholder text 2"]'));
   let tooltipImg_03 = element(by.css('#dashboard_csttextfield_03 div div label cst-tooltip span div.tooltip-icon'));
         
   beforeEach(() => {
    csttextfield_03.clear();
  });

  it('Should able to click on the text field',() => {

    console.log("\t1.0. Should click on the text field");
    browser.wait(csttextfield_03.click().then(function() { 
    browser.driver.sleep(2000); 
    }),500);
  });
  
  it('Should send key into text field and clear key',() => {
 
    console.log("\t2.0. Should send key into text field and clear key");
   'SendandClear-Key-Test'.split('').forEach((c) => csttextfield_03.sendKeys(c));
    browser.driver.sleep(1000);
    csttextfield_03.getAttribute('value').then(function(inputValue) {
     expect(inputValue).toEqual('SendandClear-Key-Test');
    });
   
    browser.driver.sleep(3000);
    csttextfield_03.clear();
    browser.driver.sleep(3000);
  });

  it('Should select and unselect text', () => {
  
    console.log("\t3.0. Should select text and unselect text");
    csttextfield_03.click();
    browser.driver.sleep(2000);
    'Select-Text-Test'.split('').forEach((c) => csttextfield_03.sendKeys(c));

    browser.driver.sleep(1000);
    csttextfield_03.getAttribute('value').then(function(inputValue) {
       //console.log(inputValue);
      });
       
    browser.driver.sleep(3000);
    csttextfield_03.sendKeys(protractor.Key.CONTROL, "a");
    browser.driver.sleep(3000);  

    var highlightedText = browser.executeScript(function getSelectionText()       
      {         
           return window.getSelection().toString(); 
      });
    expect(highlightedText).toEqual('Select-Text-Test');

    browser.driver.sleep(1000); 
    csttextfield_03.click();
    browser.driver.sleep(1000); 
 
  });

  it('Should delete the text', () => {
   
    console.log("\t4.0. Should delete the text"); 
   'Back-Space-Test'.split('').forEach((c) => csttextfield_03.sendKeys(c));

   csttextfield_03.getAttribute('value').then(function(inputValue) {
     expect(inputValue).toEqual('Back-Space-Test');
    });

   csttextfield_03.sendKeys(protractor.Key.BACK_SPACE);
   browser.driver.sleep(1000);
   csttextfield_03.getAttribute('value').then(function(inputValue) {
     expect(inputValue).toEqual('Back-Space-Tes');
    });
 
     for (let i = 0; i < 4; i++) { 
         browser.driver.sleep(1000);
          csttextfield_03.sendKeys(protractor.Key.BACK_SPACE);
      }
    });

  it('should click/unclick the Tooltip ', () => {

    console.log("\t5.0. should click/unclick the Tooltip of textfield_03"); 
    
    browser.actions().mouseMove(csttextfield_03).perform();
    browser.driver.sleep(2000);

    browser.wait(tooltipImg_03.click().then(function() { 

    browser.driver.sleep(3000); // timeout to check the above operation with naked eye!
    }),5000);

     tooltipImg_03.click();
     browser.driver.sleep(3000)
  });
});

});
