describe('UI Automation Tests: CST Grid component', function() {
   "use strict";

  //opening broweser only once for all test cases
  //  browser.get(process.env.UI_APP_URL || 'http://localhost:3000', 18000000);
  // browser.waitForAngular();

   var btn_ctx_menu = element(by.id('float_menu'));
   var elements = element.all(protractor.By.css('.menu .showMenu'));
   let grid_colomns = element.all (protractor.By.css('.k-grid-header .k-header'));

  it('Should hover the mouse over floating menu', () => {

    console.log('\t1.Hovering the mouse over floating menu');
    browser.actions().mouseMove(btn_ctx_menu).perform();
    browser.driver.sleep(3000);

    console.log("\t2.Clicking over the context menu");
    browser.wait(btn_ctx_menu.click().then(function() { 
    browser.driver.sleep(1000);
    
    console.log("\t3.Clicking the CST Button Group in the floating menu items")
    elements.get(8).click().then(function() {
      browser.driver.sleep(1000); 
    }, 120);
  })) 
});
  
it('Should get able to filter single grid columns',() => {
   console.log("\n\t1.0. Should get able to filter single grid columns"); 

   grid_colomns.each(function(element, index) {
        if(index == 0){
         console.log("\n\t\t Perform filter Opration on fistColumn"); 
          performFilter(getColumnTextbox(element), getColumnButton(element), 'ch');
          clearFilter(getColumnTextbox(element), getColumnButton(element));
        }else if(index == 1){
          console.log("\n\t\t Perform filter Opration on secondColumn"); 
           performFilter(getColumnTextbox(element), getColumnButton(element), 'bot');
          clearFilter(getColumnTextbox(element), getColumnButton(element));
        }
      });
    });

it('Should get able to filter multiple grid columns',() => {
   console.log("\n\t2.0. Should get able to filter multiple grid columns"); 
   grid_colomns.each(function(element, index) {
        if(index == 0){
          console.log("\n\t\t Perform filter Opration on fistColumn"); 
          performFilter(getColumnTextbox(element), getColumnButton(element), 'ch');
        }else if(index == 1){
           console.log("\n\t\t Perform filter Opration on secondColumn"); 
           performFilter(getColumnTextbox(element), getColumnButton(element), 'bot');
        }
      });
    grid_colomns.each(function(element, index) {
        if(index == 0 || index == 1){
          clearFilter(getColumnTextbox(element), getColumnButton(element));
        }
      });
  });

var getColumnTextbox = function(gridColumn) {
    return gridColumn.all(by.css('input'));
};

var getColumnButton = function(gridColumn) {
    return gridColumn.all(by.css('button'));
};


var performFilter = function(columnTextbox, columnButton, filterString){
     
        console.log("\t\t\t Type Data to be filter"); 
        columnTextbox.click();
        filterString.split('').forEach((c) => columnTextbox.sendKeys(c));
        browser.driver.sleep(1000);
        
        columnTextbox.getAttribute('value').then(function(inputValue){
        expect(inputValue).toEqual([filterString]) });
        
        console.log("\t\t\t Click on Go button to filter"); 
        columnButton.click();
        browser.driver.sleep(1000);
      
  }

  var clearFilter = function(columnTextbox, columnButton){
     
        console.log("\t\t\t Clear the filter"); 

         for (let i = 0; i < 3; i++) { 
             columnTextbox.sendKeys(protractor.Key.BACK_SPACE);
             browser.driver.sleep(500);
         }
        
        columnTextbox.click();
        browser.driver.sleep(500);
        columnButton.click();
        browser.driver.sleep(500);
        columnTextbox.getAttribute('value').then(function(inputValue){
        expect(inputValue).toEqual(['']) });
        browser.driver.sleep(1000);
   }

});
