describe('UI Automation Tests: DropDown Menu', function() {
  "use strict";

   var cst_dropdown_component = element(by.id('home_cst_dropdown_01'));
   var cst_dropdown = cst_dropdown_component.all(by.css('div select'));
   var btn_ctx_menu = element(by.id('float_menu'));
   var elements = element.all(protractor.By.css('.menu .showMenu'));
  
  it('should click Dropdown from float menu', () => {

    console.log('\thovering the mouse on float menu');
    browser.actions().mouseMove(btn_ctx_menu).perform();
    browser.driver.sleep(3000);

    console.log("\tclicking over the context menu");
    browser.wait(btn_ctx_menu.click().then(function() {
    browser.driver.sleep(2000);  
      console.log('\tclicking over the Dropdown');
    elements.get(2).click().then(function() {
    browser.driver.sleep(2000); 
      }, 120);
    }))
  });

  it('Should have dropDown and Tooltip', () => {

    console.log("\t");
    console.log("\t Should have dropDown and Tooltip"); 
    let tooltipElement = cst_dropdown_component.all(by.css('div label cst-tooltip'));
    
    expect(cst_dropdown_component.isPresent()).toEqual(true);
  }); 

  it('should click/unclick on dropDown the Tooltip ', () => {

   console.log("\t");
   console.log("\tShould click/unclick on the dropdown Tooltip"); 
   let tooltipImg = cst_dropdown_component.all(by.css('div label cst-tooltip span img'));
  
   browser.actions().mouseMove(cst_dropdown_component).perform(); // to check component associated tool tip
   browser.driver.sleep(2000);

   browser.wait(tooltipImg.click().then(function() { 

   browser.driver.sleep(3000); // timeout to check the above operation with naked eye!

  }),5000);

   tooltipImg.click();
   browser.driver.sleep(2000)
});


  it('should open dropdown with default item as Tesla', () => {

        console.log("\t");
        console.log("\tShould open default dropDown item as Tesla");
        
        expect(cst_dropdown_component.$('option:checked').getText()).toEqual('Tesla');

        browser.driver.sleep(3000);

    });
   
  it('should able to see all item after click',() => {

        console.log("\t");
        console.log("\tShould able to see all item after click");
        
        cst_dropdown.click();
        
        browser.driver.sleep(3000); // timeout to check the above operation with naked eye!
        expect(getOptions(cst_dropdown).count()).toBe(4);
    });

  it('should able to click specific option number 3 as Lamborghini',() => {
         console.log("\t");
         console.log("\tShould be able to click on specific option number 3 as Lamborghini");

         selectByValue(cst_dropdown,3);
         browser.driver.sleep(3000); // timeout to check the above operation with naked eye!       
         expect(cst_dropdown_component.$('option:checked').getText()).toEqual('Lamborghini');
    });

  it('should able to click on each  items', () => {
        console.log("\t");
        console.log("\tShould able to click on each of the items in dropdown");

        browser.wait(cst_dropdown_component.click().then(function() { // opens the context menu

        console.log("\t1.0. Opening dropdown ");
        browser.driver.sleep(500); // timeout to check the above operation with naked eye!
        
        var i = 1;
       
        // click all menu items found in the context menu
        getOptions(cst_dropdown_component).each(function(element, index) {

            element.click().then(function() {
                browser.driver.sleep(3000); // timeout to check the above operation with naked eye!
                console.log("\t." + i + ". Clicking dropdown items");
                i++;
            }, 120);
        });
        expect(cst_dropdown_component.isPresent()).toBe(true);

    }), 10000000);

  });

//----------------------------------------------------------------------------------------------------------------------------------------------------//

var selectByValue = function(dropdownElement, value) {
    return dropdownElement.all(by.css('option[value="' + value + '"]')).click();
};


var getOptions = function(dropdownElement) {
    return dropdownElement.all(by.tagName('option'));
};

});