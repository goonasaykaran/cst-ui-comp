describe('UI Automation Tests: Kitchen Sink: CST component', function() {
  "use strict";


  var btn_ctx_menu = element(by.id('float_menu'));
  var elements = element.all(protractor.By.css('.menu .showMenu'));

  let radio_buttons = element(by.css('cst-radiobutton div .row'));
  let radio_tooltip = element(by.css('cst-radiobutton  div span cst-tooltip span div.tooltip-icon'));



 it('Should hover the mouse over floating menu', () => {

    console.log('\t1.Hovering the mouse over floating menu');
    browser.actions().mouseMove(btn_ctx_menu).perform();
    browser.driver.sleep(3000);

    console.log("\t2.Clicking over the context menu");
    browser.wait(btn_ctx_menu.click().then(function() { 
    browser.driver.sleep(1000);
    
    console.log("\t3.Clicking the CST Button Group in the floating menu items")
    elements.get(4).click().then(function() {
    browser.driver.sleep(1000); 
    }, 120);
  })) 
});

it('Should click on the radio buttons',() => {

    console.log("\t1.0. Should click on the radio buttons");
    
    browser.driver.sleep(5000);
    console.log("\t\t Should click on the male radio button");
    element.all(by.css('cst-radiobutton input[type="radio"]')).get(0).click();
    browser.driver.sleep(5000);
    console.log("\t\t Should click on the female radio button");
    browser.driver.sleep(5000);
    element.all(by.css('cst-radiobutton input[type="radio"]')).get(1).click();
    browser.driver.sleep(5000);
});

it('should click/unclick the Tooltip ', () => {

    console.log("\t2.0. Should click/unclick the Tooltip"); 

 
    browser.actions().mouseMove(radio_buttons).perform();
    browser.driver.sleep(3000);
    browser.wait(radio_tooltip.click().then(function() { 
    browser.driver.sleep(3000); // timeout to check the above operation with naked eye!
  }),5000);

    browser.driver.sleep(3000)
    radio_tooltip.click();
    browser.driver.sleep(3000)
});

});

