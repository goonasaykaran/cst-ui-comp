describe('UI Automation Tests: CST component', function() {
   "use strict";

  //opening broweser only once for all test cases
  // browser.get(process.env.UI_APP_URL || 'http://localhost:3000', 18000000);
  // browser.waitForAngular();


   var btn_ctx_menu = element(by.id('float_menu'));
   var elements = element.all(protractor.By.css('.menu .showMenu'));
   let  show_dialog = element(by.css('cst-button [name="Show Dialog"]'));
   let dialog_back = element(by.css('cst-dialog cst-button [name ="Back"]')); 
   let dialog_proceed = element(by.css('cst-dialog cst-button [name ="Proceed"]')); 

  it('Should hover the mouse over floating menu', () => {

    console.log('\t1.Hovering the mouse over floating menu');
    browser.actions().mouseMove(btn_ctx_menu).perform();
    browser.driver.sleep(3000);

    console.log("\t2.Clicking over the context menu");
    browser.wait(btn_ctx_menu.click().then(function() { 
    browser.driver.sleep(1000);
    
    console.log("\t3.Clicking the CST Button Group in the floating menu items")
    elements.get(7).click().then(function() {
      browser.driver.sleep(1000); 
    }, 120);
  })) 
});
  
it('Should click on the Back button',() => {
   console.log("\t1.0. Should click on Back button and dialog"); 
   show_dialog.click();
   browser.driver.sleep(5000);

   console.log("\t\tHover mouse on Back button"); 
   browser.actions().mouseMove(dialog_back).perform();
   browser.sleep(3000);

   console.log("\t\t Hold mouse on Back button"); 
   browser.actions().mouseDown(dialog_back).perform();
   browser.sleep(3000);

   console.log("\t\t Release mouse hold on Back button"); 
   browser.actions().mouseUp(dialog_back).perform();

});

it('Should click on  the Proceed button',() => {
   console.log("\t1.0. Should click on Proceed button and dialog"); 
   show_dialog.click();
   browser.driver.sleep(5000);
   
   console.log("\t\t Hover Mouse on Proceed button"); 
   browser.actions().mouseMove(dialog_proceed).perform();
   browser.sleep(3000);

   console.log("\t\t Hold mouse on Proceed button"); 
   browser.actions().mouseDown(dialog_proceed).perform();
   browser.sleep(3000);

   console.log("\t\t Release mouse on Proceed button"); 
   browser.actions().mouseUp(dialog_proceed).perform();

});

});
