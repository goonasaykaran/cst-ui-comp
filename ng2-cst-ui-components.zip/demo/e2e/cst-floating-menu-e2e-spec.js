describe('UI Automation Tests: Context Menu', () => {
	"use strict";

	var btn_ctx_menu = element(by.id('float_menu'));
	var sg_body = element(by.css('.sg-body'));
	var elements = element.all(protractor.By.css('.menu .showMenu'));
   
	it('Should hover the mouse over floating menu', () => {

	    console.log('\t1.Hovering the mouse over floating menu');
	    browser.actions().mouseMove(btn_ctx_menu).perform();
	    browser.driver.sleep(3000);

	    console.log("\t2.Clicking over the context menu");
	    browser.wait(btn_ctx_menu.click().then(function() { 
	    	browser.driver.sleep(3000);
	    	console.log("\t3.Clicking the CST Floating Menu in the floating menu items")
	    	elements.get(5).click().then(function() {
	   			browser.driver.sleep(3000);
	   			browser.wait(btn_ctx_menu.click());
	     	}, 120);
	 	})) 
	});

	it('Should be able to see all menu items after click and hover the mouse away from float menu', () => {

		console.log("\tHover over the context menu");
	    browser.actions().mouseMove(btn_ctx_menu).perform();
		browser.driver.sleep(3000);

		console.log("\tClicking over the context menu");
		browser.wait(btn_ctx_menu.click().then(function() { 

	  		console.log("\tOpening Context Menu");
			browser.driver.sleep(3000); // timeout to check the above operation with naked eye!

			var elements = element.all(protractor.By.css('.menu .showMenu'));
			expect(elements.count()).toEqual(9);
			browser.driver.sleep(3000);


			console.log("\tMoving away from the context menu");
			browser.actions().mouseMove(sg_body).perform();
			browser.driver.sleep(3000); // timeout to check the above operation with naked eye!

			 // timeout to check the above operation with naked eye!

			browser.wait(element(by.id('float_menu')).click().then(function() {

				console.log("\tClosing Context Menu");
				var elements = element.all(protractor.By.css('.menu .showMenu '));
				expect(elements.count()).toEqual(0);
				
				browser.driver.sleep(3000);
			}), 900);
		}), 30000);
	})

	/*it('Should test menu items of context menu', () => {

		// here we open the context menu and test wheter expected number of menu items are present
		browser.wait(btn_ctx_menu.click().then(function() { // opens the context menu
			console.log("\t1.1. Opening Context Menu");
			browser.driver.sleep(50); // timeout to check the above operation with naked eye!
			var elements = element.all(protractor.By.css('.menu .showMenu'));
			expect(elements.count()).toEqual(5);
			
			var i = 1;
			// click all menu items found in the context menu
			elements.each(function(element, index) {
				element.click().then(function() {
					browser.driver.sleep(3000); // timeout to check the above operation with naked eye!
					console.log("\t2." + i + ". Clicking a Menu Item on the Context Menu");
					i++;
				}, 120);
			});
			expect(btn_ctx_menu.isPresent()).toBe(true);
			// here we close the context menu
			browser.wait(btn_ctx_menu.click());
		}), 30000);
	});*/
	});