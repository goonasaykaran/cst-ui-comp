describe('\t\tTests for CSTButtonGroup Component', () => {
    "use strict";
    
    
    var btn_ctx_menu = element(by.id('float_menu'));
    var elements = element.all(protractor.By.css('.menu .showMenu'));
    
    var multiSelectBtnGroup = element(by.css('cst-buttongroup  [id= "1"]'));
    var singleSelectBtnGroup = element(by.css('cst-buttongroup [id= "2"]'));
    var desableBtnGroup = element(by.css('cst-buttongroup [id= "3"]'));
    var smallBtnGroup = element(by.css('cst-buttongroup [id= "4"]'));
    var validateBtnGroup = element(by.css('cst-buttongroup [id= "5"]'));
   
  
    it('Should hover the mouse over floating menu', () => {

    console.log('\t1.Hovering the mouse over floating menu');
    browser.actions().mouseMove(btn_ctx_menu).perform();
    browser.driver.sleep(3000);

    console.log("\t2.Clicking over the context menu");
    browser.wait(btn_ctx_menu.click().then(function() { 
    browser.driver.sleep(1000);
    
    console.log("\t3.Clicking the CST Button Group in the floating menu items")
    elements.get(6).click().then(function() {
      browser.driver.sleep(1000); 
    }, 120);
   })) 
  });

 it('Should hover the mouse arrow over button groups',() => {
    
    console.log('\tHovering the mouse over multiSelectBtnGroup ')
    hoverAllbuttonFromGroup(multiSelectBtnGroup);
    
    console.log('\tHovering the mouse over singleSelectBtnGroup ');
    hoverAllbuttonFromGroup(singleSelectBtnGroup);
    
    console.log('\tHovering the mouse over desableBtnGroup ');
    browser.actions().mouseMove(desableBtnGroup).perform();
    browser.driver.sleep(1000);
    
    console.log('\tHovering the mouse over smallBtnGroup');
     hoverAllbuttonFromGroup(smallBtnGroup);

    console.log('\tHovering the mouse over validateBtnGroup');
    hoverAllbuttonFromGroup(validateBtnGroup);

  });

 it('Should able to click on every button in enabled button group',() => {
    
    console.log('\tHovering the mouse over multiSelectBtnGroup ')
    clickAllbuttonFromGroup(multiSelectBtnGroup);
    
    console.log('\tHovering the mouse over singleSelectBtnGroup ');
    clickAllbuttonFromGroup(singleSelectBtnGroup);
    
    
    console.log('\tHovering the mouse over smallBtnGroup');
     clickAllbuttonFromGroup(smallBtnGroup);

       console.log('\tHovering the mouse over validateBtnGroup');
     clickAllbuttonFromGroup(validateBtnGroup);

  });

 it('Should able to click on specific button and unselect few in enabled button group',() => {
    
    console.log('\tHovering the mouse over multiSelectBtnGroup ')
    clickSpecificbuttonFromGroup(multiSelectBtnGroup, 2);
    clickSpecificbuttonFromGroup(multiSelectBtnGroup, 1);
    clickSpecificbuttonFromGroup(multiSelectBtnGroup, 2);
    
    console.log('\tHovering the mouse over singleSelectBtnGroup ');
    clickSpecificbuttonFromGroup(singleSelectBtnGroup, 1);
    clickSpecificbuttonFromGroup(singleSelectBtnGroup, 2);
    
    
    console.log('\tHovering the mouse over smallBtnGroup');
    clickSpecificbuttonFromGroup(smallBtnGroup, 1);
    clickSpecificbuttonFromGroup(smallBtnGroup, 4);
    clickSpecificbuttonFromGroup(smallBtnGroup, 2);
    clickSpecificbuttonFromGroup(smallBtnGroup, 3);
    clickSpecificbuttonFromGroup(smallBtnGroup, 4);
    clickSpecificbuttonFromGroup(smallBtnGroup, 9);

    console.log('\tHovering the mouse over validateBtnGroup ');
    clickSpecificbuttonFromGroup(validateBtnGroup, 1);
    clickSpecificbuttonFromGroup(validateBtnGroup, 2);
    clickSpecificbuttonFromGroup(validateBtnGroup, 3);

  });

var hoverAllbuttonFromGroup = function(buttongroup) {

       buttongroup.all(by.css('button')).each(function(element) {
          browser.actions().mouseMove(element).perform();
          browser.driver.sleep(500);        
        }); 
};

var clickAllbuttonFromGroup = function(buttongroup) {

       buttongroup.all(by.css('button')).each(function(element) {
          element.click();
          browser.driver.sleep(500);        
        }); 
    };

var clickSpecificbuttonFromGroup = function(buttongroup, value) {

       buttongroup.all(by.css('button')).each(function(element, index) {
         if(value === index){
          element.click();
          browser.driver.sleep(500);        
        }
        }); 
    };
}); 

  