import { Component } from '@angular/core';
import * as moment from 'moment';

import { AppState } from '../app.service';
import { Title } from './title';
import { XLarge } from './x-large';
/*import { Image } from './img/svg';*/

@Component({
  // The selector is what angular internally uses
  // for `document.querySelectorAll(selector)` in our index.html
  // where, in this case, selector is the string 'home'
  selector: 'home',  // <home></home>
  // We need to tell Angular's Dependency Injection which providers are in our app.
  providers: [
    Title
  ],
  // Our list of styles in our component. We may add more to compose many styles together
  styleUrls: [ './home.component.scss','../../assets/css/style.css' ],
  // Every Angular template is first compiled by the browser before Angular runs it's compiler
  templateUrl: './home.component.html'
})
export class HomeComponent {
  // Set our default values
  localState = { value: '' };
  // TypeScript public modifiers
  constructor(public appState: AppState, public title: Title) {

  }

  bindSelectedValue: string[] = [] ;
  bindSingleselectedValue: string[] = [] ;
  bindSmallbuttonValue: string[] = [] ;
  bindValidateValue: string[] = [] ;

  bindingDropdownValue: string = 'No Value has been selected'

  ngOnInit() {
    console.log('hello `Home` component');
    // this.title.getData().subscribe(data => this.data = data);
  }

  submitState(value: string) {
    console.log('submitState', value);
    this.appState.set('value', value);
    this.localState.value = '';
  }

  public testListItems: Array<{ label: string, value: string }> = [
    { label: "Ferrari", value: "1" },
    { label: "Tesla", value: "2" },
    { label: "Lamborghini", value: "3" }
  ];

  public listItems: Array<{ text: string, value: number }> = [
        { text: "Small", value: 1 },
        { text: "Medium", value: 2 },
        { text: "Large", value: 3 }
    ];

public yesNoButtons: Array<{ text: string, value: number }> = [
        { text: "Yes", value: 1 },
        { text: "No", value: 2 },
    ];

public multipleNumber: Array<{ text: string, value: number }> = [
        { text: "1", value: 1 },
        { text: "2", value: 2 },
        { text: "3", value: 3 },
        { text: "4A", value: 4 },
        { text: "4B", value: 5 },
        { text: "5", value: 6 },
        { text: "6A", value: 7 },
        { text: "6B", value: 8 },
        { text: "7A", value: 9 },
        { text: "7B", value: 10 },
        { text: "8A", value: 11 },
        { text: "8B", value: 12 },
        { text: "8C", value: 13 },
        { text: "9", value: 14 },
    ];

 public buttonItems : Array<{ text: string, value: number }> = [
        { text: "No Support", value: 1 },
        { text: "Goverment", value: 2 },
        { text: "Parent", value: 3 }
    ];

 public buttonValidateItems : Array<{ text: string, value: number }> = [
        { text: "No Support", value: 1 },
        { text: "Goverment", value: 2 },
        { text: "Parent", value: 3 }
    ];

  public radioItems: Array<{ text: string, value: string }> = [
      { text: "Male", value: "Male" },
      { text: "Female", value: "Female" }
  ];

  public gridData:any = [
  {
        "ProductID" : 1,
        "ProductName" : "Chai",
        "SupplierID" : 1,
        "CategoryID" : 1,
        "QuantityPerUnit" : "10 boxes x 20 bags",
        "UnitPrice" : 18.0000,
        "UnitsInStock" : 39,
        "UnitsOnOrder" : 0,
        "ReorderLevel" : 10,
        "Discontinued" : false,
        "Category" : {
            "CategoryID" : 1,
            "CategoryName" : "Beverages",
            "Description" : "Soft drinks, coffees, teas, beers, and ales"
        }
  },
  {
          "ProductID" : 2,
          "ProductName" : "Chang",
          "SupplierID" : 1,
          "CategoryID" : 1,
          "QuantityPerUnit" : "24 - 12 oz bottles",
          "UnitPrice" : 19.0000,
          "UnitsInStock" : 17,
          "UnitsOnOrder" : 40,
          "ReorderLevel" : 25,
          "Discontinued" : false,
          "Category" : {
              "CategoryID" : 1,
              "CategoryName" : "Beverages",
              "Description" : "Soft drinks, coffees, teas, beers, and ales"
          }
 },
 {
          "ProductID" : 2,
          "ProductName" : "Muthu",
          "SupplierID" : 1,
          "CategoryID" : 1,
          "QuantityPerUnit" : "14 - 12 oz bottles",
          "UnitPrice" : 19.0000,
          "UnitsInStock" : 17,
          "UnitsOnOrder" : 40,
          "ReorderLevel" : 25,
          "Discontinued" : false,
          "Category" : {
              "CategoryID" : 1,
              "CategoryName" : "Beverages",
              "Description" : "Soft drinks, coffees, teas, beers, and ales"
          }
 },
 {
          "ProductID" : 2,
          "ProductName" : "Set",
          "SupplierID" : 1,
          "CategoryID" : 1,
          "QuantityPerUnit" : "15 - 12 oz bottles",
          "UnitPrice" : 19.0000,
          "UnitsInStock" : 17,
          "UnitsOnOrder" : 40,
          "ReorderLevel" : 25,
          "Discontinued" : false,
          "Category" : {
              "CategoryID" : 1,
              "CategoryName" : "Beverages",
              "Description" : "Soft drinks, coffees, teas, beers, and ales"
          }
 },
 {
          "ProductID" : 2,
          "ProductName" : "Roj",
          "SupplierID" : 1,
          "CategoryID" : 1,
          "QuantityPerUnit" : "44 - 12 oz bottles",
          "UnitPrice" : 19.0000,
          "UnitsInStock" : 17,
          "UnitsOnOrder" : 40,
          "ReorderLevel" : 25,
          "Discontinued" : false,
          "Category" : {
              "CategoryID" : 1,
              "CategoryName" : "Beverages",
              "Description" : "Soft drinks, coffees, teas, beers, and ales"
          }
 },
 {
          "ProductID" : 2,
          "ProductName" : "Pri",
          "SupplierID" : 1,
          "CategoryID" : 1,
          "QuantityPerUnit" : "54 - 12 oz bottles",
          "UnitPrice" : 19.0000,
          "UnitsInStock" : 17,
          "UnitsOnOrder" : 40,
          "ReorderLevel" : 25,
          "Discontinued" : false,
          "Category" : {
              "CategoryID" : 1,
              "CategoryName" : "Beverages",
              "Description" : "Soft drinks, coffees, teas, beers, and ales"
          }
 }
 ];

 public gridColumns:any = [
  {
    "fieldName" : "ProductName",
    "title" : "Name",
    "width" : 250,
    "filter" : true
  },
  {
    "fieldName" : "QuantityPerUnit",
    "title" : "Quantity",
    "width" : 250,
    "filter" : true
  },
  {
    "fieldName" : "UnitPrice",
    "title" : "Price",
    "width" : 100
  },
  {
    "fieldName" : "Discontinued",
    "title" : "Discontinued",
    "width" : 100
  }
 ];

  public demo_textfield_1: string='This is a value';
  public demo_textfield_2: string='alex@dbs.sg.com';
  public demo_textarea_1: string='Lorem Ipsum is simply dummy text of the printing and typesetting industry.';

  public floatingMenuButtons: Array<Object> = [
    {
      name: 'CST Textfield',
      target: '#section_one',/*action: () => console.log('hi'),*/
      iconStyles: {
        success: true
      }
    },
    {
      name: 'CST Textarea',
      target: '#section_two',
      iconStyles: {
        error: true
      }
    },
    {
      name: 'CST Dropdown',
      target: '#section_three',
      iconStyles: {
        warning: true
      }
    },
    {
      name: 'CST Button',
      target: '#section_four',
      iconStyles: {
        success: true
      }
    },
    {
      name: 'CST Redio Button',
      target: '#section_five',
      iconStyles: {
        success: true
      }
    },
    {
      name: 'CST FloatingMenu',
      target: '#section_six',
      iconStyles: {
        success: true
      }
    },
    {
      name: 'CST Button Group',
      target: '#section_nine',
      iconStyles: {
        success: true
      }
    },
    {
      name: 'CST Dialog',
      target: '#section_ten',
      iconStyles: {
        success: true
      }
    },
    {
      name: 'CST Grid',
      target: '#section_eleven',
      iconStyles: {
        success: true
      }
    }
  ];

   public dialogState: boolean = false;

   public dialogButtons: Array<Object> = [
          {
             name: 'Back',
              callback: (event: Event) => {
              event.preventDefault();
              console.log('back');
              this.dialogState = false;
              }
            },
            {
             name: 'Proceed',
             callback: (event: Event) => {
              event.preventDefault();
              console.log('proceed');
              this.dialogState = false;
              },
              isPrimary: true
            }
         ];


  showDialog(): void {
    this.dialogState = true;
  }

  checkForValidation(val): boolean {
    return false;
  }

  validationMsg: string = 'This is wrong'

  validationObject: Object = {
    validation: this.checkForValidation,
    validationMsg: this.validationMsg
  }
}
