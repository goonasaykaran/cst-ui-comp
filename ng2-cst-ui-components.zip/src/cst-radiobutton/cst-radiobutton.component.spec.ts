import { Component } from '@angular/core';
import { ComponentFixture, inject, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { CSTRadioButtonComponent } from './cst-radiobutton.component';

let radio: CSTRadioButtonComponent;

// @INPUTS...................................................
// TODO: Please fix this before pushing

describe('\nUnit Tests for CSTRadioButton component', () => {
describe('\n\tFor default input', () => {

  beforeEach(() => {
    radio = new CSTRadioButtonComponent(null);
  });

  it('should be undefined bindModelData', () => {
    expect(radio.bindModelData).toEqual(undefined);
  });

  it('should have null value ', () => {
    expect(radio._value).toEqual(null);
  });

  it('should have label ', () => {
    expect(radio.label).toEqual(undefined);
  });

  it('should show previous value  ', () => {
    expect(radio.showpreviousvalue).toBe(false);
   });

  it('should be null tooltipMessage ', () => {
    expect(radio.tooltipMessage).toEqual(null);
  });

  it('should have column viewType', () => {
    expect(radio.viewType).toEqual('column');
  });

  it('should be undefined text ', () => {
    expect(radio._text).toEqual(undefined);
  });

  it('should not focus ', () => {
    expect(radio._autofocus).toEqual(false);
  });

  it('should not be disabled', () => {
    expect(radio._disabled).toEqual(false);
  });

  it('should be Checked', () => {
    expect(radio._checked).toBe(false);
  });

  it('should be defaultChecked false', () => {
    expect(radio._defaultChecked).toBe(false);
  });

  it('should have undefined form ', () => {
    expect(radio._form).toBe(undefined);
  });

  it('should have undefined name ', () => {
    expect(radio._name).toBe(undefined);
  });

  it('should be not required', () => {
    expect(radio._required).toBe(false);
  });

});

describe('\n\tFor methods and functions', () => {

  beforeEach(() => {
    radio = new CSTRadioButtonComponent(null);
  });

 let fakeFunction = function() {
      return;
    };

  /*it('should update the data', () => {
    radio.updateData('Radio');
    expect(radio.bindModelData).toEqual('Radio');
  });
*/
  it('should have radiButtonColumnClass when Options Count is less than 6', () => {

    let radioItems: Array<{ text: string, value: string }> = [
      { text: 'Male', value: 'Male' },
      { text: 'Female', value: 'Female' }
    ];
    radio.options = radioItems;
    radio.setColumnWidth();
    // in this senario, following bootstrap class is expected on the RadioButton Component
    expect(radio.radiButtonColumnClass).toEqual('col-md-6 col-sm-6');
    });

  it('should invoke setColumnWidth by ngOnInit()', () => {

    spyOn(radio, 'setColumnWidth');
    radio.ngOnInit(); // invokes the method to be tested
    expect(radio.setColumnWidth).toHaveBeenCalled();
    expect((<any>radio).setColumnWidth.calls.count()).toBe(1);
  });

  it('should Change the value', () => {

    radio.previousValue = 'Previous Value';
    radio.currentValue = 'Current Value';
    radio.setChangedValue('test value');
    expect(radio.currentValue).toEqual('test value');
    expect(radio.previousValue).toEqual('Current Value');
  });

  it('should get GUID', () => {
    radio.getGUID();
    expect(radio.getGUID()).toEqual('ui303');
  });

  it('should set selected value', () => {
    radio.setSelectedValue('test value');
    expect(radio._value).toEqual('test value');
  });

  it('should update value while invoking Writevalue', () => {  //  @ Hamzeen
    // mocks the call to setSelectedValue
    spyOn(radio, 'setSelectedValue').and.callFake(function() {
    return;
    });
    // invokes the method to be tested
    radio.writeValue('Radio New Value');
    // ensure setSelectedValue() was called once & value of Component was updated
    expect(radio.setSelectedValue).toHaveBeenCalled();
    expect((<any>radio).setSelectedValue.calls.count()).toBe(1);
    expect((<any>radio)._value).toEqual('Radio New Value');
  });

  it('should registerOnChange', () => {
    radio.registerOnChange(fakeFunction);
    expect(radio.onChangeCallback).toEqual(fakeFunction);
  });

  it('should registerOnTouched', () => {
    radio.registerOnTouched(fakeFunction);
    expect(radio.onTouchedCallback).toEqual(fakeFunction);
  });
 });
});
