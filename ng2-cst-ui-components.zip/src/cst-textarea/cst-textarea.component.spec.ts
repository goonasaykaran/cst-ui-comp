import { Component } from '@angular/core';
import { ComponentFixture, inject, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { CSTTextareaComponent } from './cst-textarea.component';

let textarea: CSTTextareaComponent;

describe('\nUnit Tests for CSTTextareaComponent', () => {

describe('\n\tFor Input properties', () => {

  beforeEach(() => {
      textarea = new CSTTextareaComponent();
  });

  it('should be \'text\' type', () => {
    expect(textarea.type).toEqual('text');
  });

  it('should have lable with undefine', () => {
    expect(textarea.label).toEqual(undefined);
  });

  it('should have null tooltipMsg', () => {
    expect(textarea.tooltipMsg).toBe(null);
  });

  it('should have null tooltipType', () => {
    expect(textarea._tooltipType).toEqual(null);
  });

  it('should have empty placeholder', () => {
    expect(textarea.placeholder).toBe('');
  });

  it('should not be disabled', () => {
    expect(textarea.disabled).toBe(false);
  });

  it('should not a mandatory field', () => {
    expect(textarea.isRequired).toBe(false);
  });

  it('should show value change', () => {
    expect(textarea.showValueChange).toBe(false);
  });

  it('should have undefined rows and columns', () => {
    expect(textarea.rows).toEqual(undefined);
    expect(textarea.cols).toEqual(undefined);
  });

});

describe('\n\tFor methods and functions', () => {

  beforeEach(() => {
      textarea = new CSTTextareaComponent();
  });

  it('should be able to logg console message on init', () => {

    spyOn(console, 'log');
    textarea.ngOnInit(); // invokes the method to be tested
    expect(console.log).toHaveBeenCalled();
    expect((<any>console).log.calls.count()).toBe(1);
  });

  it('should able to resize', () => {
    textarea.resize = '400';
    expect(textarea.resize).toBe('true');
  });

  it('should fail resizing', () => {
   // invokes the setter method of resize
    textarea.resize = false;
    expect(textarea.resize).toBe('none');
  });


  it('should be able to change value', () => {
    textarea.showValueChange = true;
    let innerValue = 'TextAreaInnervalue';
    textarea.value = 'TextAreaValue';

    expect(textarea.value).toEqual('TextAreaValue');
    expect(textarea.isValueChanged).toEqual(true);
  });

  it('should be able to get and set value', () => {
   // invokes the setter method of value
    let innerValue = 'TextAreaInnervalue';
    textarea.value = 'TextAreaValue';
    // verifies the value using the getter method of value
    expect(textarea.value).toEqual('TextAreaValue');
  });

  it('should call onChangeCallback if set value is invoked', () => {
    // mocks the call to onChangeCallback
    spyOn(textarea, 'onChangeCallback').and.callFake(function() {
      return;
    });
    // invokes the method to be tested
    textarea.value = 'text';
    // verifications
    expect(textarea.onChangeCallback).toHaveBeenCalled();
    expect((<any>textarea).onChangeCallback.calls.count()).toBe(1);
  });

  it('should call onTouchCallback() if onBlur() is invokes', () => {  // @ Hamzeen
    // mocks the call to onTouchedCallback
    spyOn(textarea, 'onTouchedCallback').and.callFake(function() {
      return;
    });
    // invokes the method to be tested
    textarea.onBlur();
    // verifications
    expect(textarea.onTouchedCallback).toHaveBeenCalled();
    expect((<any>textarea).onTouchedCallback.calls.count()).toBe(1);
  });

  it('should change the value while invoking Writevalue', () => {

    let innerValue = 'TextAreaInnervalue';
    textarea.writeValue('TextAreaValue');
    // verification
    expect(textarea.value).toEqual('TextAreaValue');
  });

  it('should registerOnChange', () => {

    let fakeFunction = function() {
      return;
    };
    textarea.registerOnChange(fakeFunction);
    // verifications
    expect(textarea.onChangeCallback).toEqual(fakeFunction);
  });

  it('should registerOnTouched', () => {

    let fakeFunction = function() {
      return;
    };
    textarea.registerOnTouched(fakeFunction);
    // verifications
    expect(textarea.onTouchedCallback).toEqual(fakeFunction);
  });
 });
});

