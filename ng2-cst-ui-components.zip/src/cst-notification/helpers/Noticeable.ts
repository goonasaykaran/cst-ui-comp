
/**
 * Notification Observer classes should implement this interface
 */
interface INoticeable {
    notify(notice: any): void;
}
// Added an interface Noticeable
interface Noticeable {
    close(): void;
}
// Exported Noticeable and INoticeable
export {Noticeable}
export {INoticeable}
