import { INoticeable, Noticeable } from './Noticeable';
import _ from 'lodash';

export class Notifier {

    private static instance: Notifier;
    private notificationObservers: Array<INoticeable> = new Array();

    public static getInstance(): Notifier {

        if (Notifier.instance == null) {
            Notifier.instance = new Notifier();
        }
        return Notifier.instance;
    }

    constructor() {
        this.notificationObservers = new Array();
    }

    registerObserver(observer: INoticeable): void {
        this.notificationObservers.push(observer);
    }

    removeObserver(observer: INoticeable): void {
        this.notificationObservers.splice(this.notificationObservers.indexOf(observer), 1);
        // _.remove( this.notificationObservers, function(iterator) {
        //   return iterator.getGUID() === observer.getGUID();
        // });
    }

    notify(notice: any): void {
        _.forEach(this.notificationObservers, function(observer: INoticeable): void {
            observer.notify(notice);
        });
    }

    close(): void {
        _.forEach(this.notificationObservers, function(observer: Noticeable): void {
            observer.close();
        });
    }
}
