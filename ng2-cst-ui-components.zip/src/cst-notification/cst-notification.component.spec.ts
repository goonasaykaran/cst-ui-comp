import { TestBed } from '@angular/core/testing';
import { CSTNotificationComponent } from './cst-notification.component';
import { Notifier } from './helpers/Notifier';


let notification: CSTNotificationComponent;
const dialogButtons: Array<Object> = [{	name: 'Ignore',
                                               callback(event: Event): void {event.preventDefault();
                                               console.log('accepting_1'); }},
                                      { name: 'Proceed',
                                               callback(event: Event): void {event.preventDefault();
                                               console.log('accepting_2'); }}];

beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ CSTNotificationComponent ]
        });
        notification = new CSTNotificationComponent();
});

describe('\nUnit Test Case for CSTNotificationComponent', () => {

    describe('\n\tFor Input properties default', () => {   // show notification test to be done

        it('should create an instance of component', () => {
            expect(notification instanceof CSTNotificationComponent).toBe(true);
        });
    });

        it('should show if they are passed to component', () => {
            (<any>notification).state.buttons = dialogButtons;
                expect((<any>notification).state.buttons).toEqual(dialogButtons);
        });

        it('should NOT show they are NOT passed to component', () => {
            expect((<any>notification).state.buttons).toEqual([]);
        });


    describe('\n\t For message', () => {
        const message: string = 'This is a message';
        it('should show if they are passed to component', () => {
            (<any>notification).state.message = message;
            expect((<any>notification).state.message).toEqual(message);
        });

        it('should NOT show if they are NOT passed to component', () => {
            expect((<any>notification).state.message).toEqual(null);
        });
    });

    describe('\n\tcloseDialog button', () => {
        it('should show by default', () => {
            expect((<any>notification).state.showCloseButton).toBeTruthy();
        });

        it('should NOT show if showCloseButton is false', () => {
            (<any>notification).state.showCloseButton = false;
            expect((<any>notification).state.showCloseButton).toBeFalsy();
        });
    });

    describe('\n\tFor header', () => {
        const title: string = 'The Title';

        it('title should be the same as passed in value', () => {
            (<any>notification).state.title = title;
            expect((<any>notification).state.title).toEqual(title);
    });

        it('should show right icons and header color for success ', () => {
            (<any>notification).dialogClass.success = true;
            expect((<any>notification).dialogClass.success).toBeTruthy();
        });

        it('should show right icons and header color for error ', () => {
            (<any>notification).dialogClass.error = true;
            expect((<any>notification).dialogClass.error).toBeTruthy();
        });

        it('should show right icons and header color for warning ', () => {
            (<any>notification).dialogClass.warning = true;
            expect((<any>notification).dialogClass.warning).toBeTruthy();
        });

        it('should show right icons and header color for neutral ', () => {
            (<any>notification).dialogClass.neutral = true;
            expect((<any>notification).dialogClass.neutral).toBeTruthy();
        });

});

describe('\n\t Functions invoking methods', () => {

    it('should be able to logg console message on init', () => {
      spyOn(console, 'log');
      notification.ngOnInit(); // invokes the method to be TestBed			
      expect(console.log).toHaveBeenCalled();
      expect((<any>console).log.calls.count()).toBe(1);
    });

    it('should be able to logg console message after init', () => {
     spyOn(console, 'log');
     notification.ngAfterViewInit(); // invokes the method to be TestBed			
     expect(console.log).toHaveBeenCalled();
     expect((<any>console).log.calls.count()).toBe(1);
  });


    it('should able to close notification dialog box after 5 seconds', () => {
     spyOn(window, 'setTimeout').and.callFake(function() {
     return;
    });

        spyOn(notification, 'onCloseDialog').and.callFake(function() {
          return;
        });
    notification.autoCloseNotification(); // invokes the method to be tested
    expect(window.setTimeout).toHaveBeenCalled();
   // expect(notification.onCloseDialog).toHaveBeenCalled();
   // expect(notification.onCloseDialog.calls.count()).toBe(1);
  });

    it('should able to invoke onCloseDialog() from close() method', () => {
     spyOn(notification, 'onCloseDialog').and.callFake(function() {
      return;
    });

    notification.close(); // invokes the method to be tested
    expect(notification.onCloseDialog).toHaveBeenCalled();
    expect((<any>notification).onCloseDialog.calls.count()).toBe(1);
  });
 });

describe('\n\tbuttonsAvailable()', () => {

    it('should able to return false when buttons are not available', () => {
        expect(notification.buttonsAvailable()).toBe(false);
    });

    it('should able to return true when buttons are available', () => {
        (<any>notification).state.buttons = dialogButtons;
        expect(notification.buttonsAvailable()).toBe(true);
    });
});

describe('\n\tshouldAutoCloseNotification', () => {

    it('should able to invoke buttonsAvailable() and return true when buttons are not available',
      () => {

        spyOn(notification, 'buttonsAvailable').and.callFake(function() {
        return;
        });
        (<any>notification).state.showCloseButton = false;
        notification.shouldAutoCloseNotification();
        expect(notification.buttonsAvailable).toHaveBeenCalled();
        expect(notification.shouldAutoCloseNotification()).toEqual(true);
    });

    it('should able to invoke buttonsAvailable() and return true when buttons are available',
        () => {

        (<any>notification).state.buttons = dialogButtons;
        spyOn(notification, 'buttonsAvailable').and.callFake(function() {
        return ;
    });
        (<any>notification).state.autoClose = true;
        notification.shouldAutoCloseNotification();
        expect(notification.shouldAutoCloseNotification()).toEqual(true);
    });

});

describe('\n\tshouldHideIcon', () => {

    it('should able to invoke buttonsAvailable() when buttons are not available and message is null', () => {

        spyOn(notification, 'buttonsAvailable').and.callFake(function() {
        return;
    });
        notification.shouldHideIcon();
        expect(notification.shouldHideIcon()).toEqual(true);

});

    it('should able to invoke buttonsAvailable() when buttons are available and message is not null', () => {
        (<any>notification).state.buttons = dialogButtons;
        spyOn(notification, 'buttonsAvailable').and.callFake(function() {
        return true;
    });

        (<any>notification).state.message = 'This is message';
        notification.shouldHideIcon();
        expect((<any>notification).state.message).toBe('This is message');
        expect(notification.shouldHideIcon()).toEqual(false);
    });

    it('ngOnDestroy()', () => {
        Notifier.getInstance().removeObserver(notification);
    });
 });

describe('\n\tgetDialogClass()', () => {

    it('should invoke getDialogClass method to set success and no-message to true by default', () => {

        let expectedObject: Object = { success: true, error: false, neutral: false, warning: false, 'no-message': true,
                                      'no-close-button': false };
        notification.getDialogClass();
        expect(notification.dialogClass[(<any>notification).state.type]).toBe(true);
        expect((<any>notification).dialogClass['no-message']).toBe(true);

        expect((<any>notification).dialogClass).toEqual(expectedObject);
    });

    it('should invoke getDialogClass method to set success, no-message and no-close-button true', () => {

        let expectedObject: Object = { success: true, error: false, neutral: false, warning: false, 'no-message': true,
                                      'no-close-button': true };
        (<any>notification).state.showCloseButton = false;
        (<any>notification).getDialogClass();

        expect(notification.dialogClass[(<any>notification).state.type]).toBe(true);
        expect((<any>notification).dialogClass['no-close-button']).toBe(true);
        expect((<any>notification).dialogClass).toEqual(expectedObject);
    });

    it('should invoke getDialogClass method to set success, no-message and no-close-button true when buttons and message is passed', () => {

        let expectedObject: Object = { success: true, error: false, neutral: false, warning: false, 'no-message': false,
                                      'no-close-button': true };
        (<any>notification).state.message = 'This is message';
        (<any>notification).state.buttons = dialogButtons;
        notification.getDialogClass();

        expect(notification.dialogClass[(<any>notification).state.type]).toBe(true);
        expect((<any>notification).dialogClass['no-close-button']).toBe(true);
        expect((<any>notification).dialogClass).toEqual(expectedObject);
    });

});

  describe('\n\tnotify(message:Object)', () => {

        let message: string = 'test_Message';

        it('should invoke notify method to set state object, showNotification, buttons, showIcon nad invoke autoCloseNotification', () => {

        spyOn(notification, 'autoCloseNotification').and.callFake(function() { return;  });

            notification.notify(message);
			// expect(notification.message).toBe(null);  
            expect((<any>notification).showNotification).toBe(true);
            expect((<any>notification).state.buttons).toEqual([]);
            expect((<any>notification).state.showIcon).toBe(false);
    		// expect(notification.autoCloseNotification).toHaveBeenCalled();
        });


        it('should invoke notify method to set state object and showNotification when message is passed', () => {
            (<any>notification).state.message = 'test_State_Message';
                notification.notify(message);

            expect((<any>notification).showNotification).toBe(true);
            });

        it('should invoke notify method to set state object, showNotification and invoke autoCloseNotification',
          () => {
                (<any>notification).state.message = 'test_State_Message';
                (<any>notification).state.autoClose = true;

                spyOn(notification, 'autoCloseNotification').and.callFake(function() { return; });
                notification.notify(message);

                expect(notification.showNotification).toBe(true);
                expect(notification.autoCloseNotification).toHaveBeenCalled();

        });
    });
});
