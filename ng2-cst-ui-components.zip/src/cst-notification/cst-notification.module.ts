import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { Ng2PageScrollModule } from 'ng2-page-scroll';

import { CSTNotificationComponent } from './cst-notification.component';

@NgModule({
  imports: [CommonModule, Ng2PageScrollModule.forRoot()],
  declarations: [CSTNotificationComponent],
  exports: [CSTNotificationComponent]
})

export class CSTNotificationModule {
    public static forRoot(): ModuleWithProviders
                             {return {ngModule: CSTNotificationModule, providers: []};
};
}
