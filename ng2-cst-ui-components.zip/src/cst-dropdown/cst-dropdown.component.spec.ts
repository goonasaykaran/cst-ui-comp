import { Component, Input, forwardRef, Output, EventEmitter } from '@angular/core';
import { ComponentFixture, inject, TestBed, fakeAsync, tick, getTestBed, async }
       from '@angular/core/testing';
import { CSTDropdownComponent } from './cst-dropdown.component';

let dropDown: CSTDropdownComponent;

describe('\nUnit Test for CSTDropdownComponent', () => {
describe('\n\tFor default Input properties', () => {

  beforeEach(async(() => {
      dropDown = new CSTDropdownComponent();
    }));

 it('should be able to set value and gets updated', () => {
    // invokes the setter method of value
    dropDown.value = 'test value';
    // verifies the value using the getter method of value
    expect(dropDown.value).toEqual('test value');
  });

  it('should be able to set disabled', () => {
    dropDown.disabled = true;
    expect( dropDown.disabled).toEqual(true);
  });

 it('should be able to set bindModelData', () => {
    dropDown.bindModelData = 'dropDown_bindModelData';
    expect( dropDown.bindModelData).toEqual('dropDown_bindModelData');
  });

  it('should be able to set name', () => {
    dropDown.name = 'dropdown';
    expect( dropDown.name).toEqual('dropdown');
  });

  it('should be able to set tooltip message', () => {
    dropDown.tooltipMessage = 'tooltipMessage';
    expect( dropDown.tooltipMessage).toEqual('tooltipMessage');
  });

  it('should be able to set tooltipType', () => {
    dropDown._tooltipType = 'tooltip_Type';
    expect( dropDown._tooltipType).toEqual('tooltip_Type');
  });

  it('should be able to set label ', () => {
    dropDown.label = 'tooltip_label';
    expect( dropDown.label).toEqual('tooltip_label');
  });

  it('should be able to set showpreviousvalue as true ', () => {
    dropDown.showpreviousvalue = true;
    expect( dropDown.showpreviousvalue).toEqual(true);
  });

  it('should be able to set data', () => {
    dropDown._data = 'dropdown_data';
    expect( dropDown._data).toEqual('dropdown_data');
  });

  it('should be able to set defaultItem ', () => {
    dropDown._defaultItem = 'dropdown_defaultItem';
    expect( dropDown._defaultItem).toEqual('dropdown_defaultItem');
  });

  it('should be able to set delay number', () => {
    dropDown._delay = 10;
    expect( dropDown._delay).toEqual(10);
  });

  it('should be able to set filterable to true', () => {
    dropDown._filterable = true;
    expect( dropDown._filterable).toEqual(true);
  });

  it('should be able to set height', () => {
    dropDown._height = 10;
    expect( dropDown._height).toEqual(10);
  });

  it('should be able to set ignoreCase to true', () => {
    dropDown._ignoreCase = true;
    expect( dropDown._ignoreCase).toEqual(true);
  });

  it('should able to set tabIndex number', () => {
    dropDown._tabIndex = 10;
    expect( dropDown._tabIndex).toEqual(10);
  });
});

describe('\n\tFor methods and functions', () => {

  beforeEach(async(() => {
      dropDown = new CSTDropdownComponent();
  }));

  let fakeFunction = function() { return; };
  it('should log console message on init call', () => {
    spyOn(console, 'log');
    dropDown.ngOnInit(); // invokes the method to be tested
    // verifications
    expect(console.log).toHaveBeenCalled();
    expect((<any>console).log.calls.count()).toBe(1);
  });

  it('should be able to updateData ', () => {
   let fakeEventObject: Object = {target : {value: 'update_Data'}};
   dropDown.updateData(fakeEventObject);
   expect( dropDown.bindModelData).toEqual(fakeEventObject);
 });

   it('should _setSelectedValue', () => {
    // mocks the call to setSelectedValue
    spyOn(dropDown, 'setSelectedValue').and.callFake(function() {
      return;
    });
     spyOn(dropDown, 'onChangeCallback').and.callFake(function() {
      return;
    });
    // invokes the method to be tested
    dropDown._selectedValue = 'Any_Value';
    // ensure setSeleced() was called once & value of Dropdown was updated
    expect(dropDown.setSelectedValue).toHaveBeenCalled();
    expect((<any>dropDown).setSelectedValue.calls.count()).toBe(1);
    expect(dropDown.onChangeCallback).toHaveBeenCalled();
    expect((<any>dropDown).onChangeCallback.calls.count()).toBe(1);
  });

  it('should be able to setSelectedValue', () => {
    // invokes the method to be tested
    dropDown.setSelectedValue('Dropdown_Selected_Value');
    expect(dropDown.previousValue).toEqual(null);
    expect(dropDown.value).toEqual('Dropdown_Selected_Value');
  });

  it('should be able to writeValue()', () => {
    // mocks the call to setSelectedValue
    spyOn(dropDown, 'setSelectedValue').and.callFake(function() {
      return;
    });
    // invokes the method to be tested
    dropDown.writeValue('Dropdown_New_Value');
    // ensure setSeleced() was called once & value of Dropdown was updated
    expect(dropDown.setSelectedValue).toHaveBeenCalled();
    expect((<any>dropDown).setSelectedValue.calls.count()).toBe(1);
    expect(dropDown.value).toEqual('Dropdown_New_Value');
  });

  it('should not writeValue() with undefine', () => {
    spyOn(dropDown, 'setSelectedValue').and.callFake(function() {
      return;
    });
    dropDown.writeValue(undefined);
    expect((<any>dropDown).setSelectedValue.calls.count()).toBe(0);
  });

  it('should be able to setDisabledState ', () => {
    dropDown.setDisabledState(true);
    expect( dropDown.disabled).toEqual(true);
  });

  it('should be able to registerOnChange ', () => {
    dropDown.registerOnChange(fakeFunction);
    expect( dropDown.onChangeCallback).toEqual(fakeFunction);
  });

  it('should be able to registerOnTouched ', () => {
    dropDown.registerOnTouched(fakeFunction);
    expect( dropDown.onTouchedCallback).toEqual(fakeFunction);
  });

 it('should be able to get isValueChanged ', () => {
    expect(dropDown.isValueChanged).toEqual(false);
  });

  it('should call _valueChange() if target value gets change', () => {
    let fakeEventObject: Object = {target : {value: 'selected_Value'}};

     spyOn(dropDown, 'setSelectedValue').and.callFake(function() {
      return;
    });

    dropDown._valueChange(fakeEventObject);

    expect(dropDown.setSelectedValue).toHaveBeenCalled();
    expect((<any>dropDown).setSelectedValue.calls.count()).toBe(1);
    expect(dropDown.value).toEqual('selected_Value');
    expect(dropDown._isValueChanged).toEqual(true);
  });
 });
});
