import { Component, Input, forwardRef, Output, EventEmitter } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

const noop: any = () => {
	// nothing here
};
export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
    provide : NG_VALUE_ACCESSOR,
    useExisting: forwardRef( () => CSTDropdownComponent),
    multi: true
};

@Component({
    selector: 'cst-dropdown',
    templateUrl: './cst-dropdown.component.html',
    providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
})
export class CSTDropdownComponent implements ControlValueAccessor {

    @Input() bindModelData: any = '';

    @Output() bindModelDataChange: any = new EventEmitter();

    @Input() firstOption: string = 'Please select value';

    @Input('name') name: string = '';

    @Input('tooltip') tooltipMessage: string = null;

    @Input('tooltipType') _tooltipType: string = null;

    @Input() label: string;

    @Input() showpreviousvalue: boolean = false;

    @Input('selectedValue')
    set _selectedValue(val: any) {
        this.setSelectedValue(val);
        this.onChangeCallback(val);
    }

    @Input('data') _data: any;

    @Input('value') _value: any = null;

    @Input('defaultItem') _defaultItem: any = null;

    @Input('delay') _delay: number = 0;

	// @Input('disabled') _disabled: boolean = false;
    @Input() disabled: boolean = false;

    @Input('filterable') _filterable: boolean = false;

    @Input('height') _height: number;

    @Input('ignoreCase') _ignoreCase: boolean = false;

    @Input('tabIndex') _tabIndex: number;

    localState: any;
    previousValue: string = null;
    selectedValue: string = null;
// Property changed from private to public
    public onChangeCallback: (_: any) => void = noop;
    public onTouchedCallback: (_: any) => void = noop;

    private _isValueChanged: boolean = false;

    updateData(event: any): void {
        this.bindModelData = event;
        this.bindModelDataChange.emit(event);
    }

    constructor() {
		// constructor
    }

    ngOnInit(): void {
        console.log('Init::' + this.value);
        this.updateData(this.value);
    }

    _valueChange(e: any): void {
        this.setSelectedValue(e.target.value);
        this.value = e.target.value;
        this.updateData(this.value);
        this._isValueChanged = true;
    }

   get isValueChanged(): boolean {
       return this._isValueChanged;
    }

     setSelectedValue(val: any): void {
        this.previousValue = this._value;
        this.value = val;
    }

    get value(): any {
        return this._value;
    };

    set value(v: any) {
            this._value = v;
     }

    writeValue(value: any): void {
        if (value) {
            this.value = value;
            this.setSelectedValue(value);
        }
    }

    registerOnChange(fn: any): void {
        this.onChangeCallback = fn;
    }

    registerOnTouched(fn: any): void {
        this.onTouchedCallback = fn;
    }

    setDisabledState(isDisabled: boolean): void {
        this.disabled = isDisabled;
    }
}
