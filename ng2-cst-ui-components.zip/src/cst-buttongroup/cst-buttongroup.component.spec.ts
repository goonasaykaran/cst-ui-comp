import { Component } from '@angular/core';
import { ComponentFixture, inject, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { CSTButtonGroupComponent } from './cst-buttongroup.component';

let testButtonGroup: CSTButtonGroupComponent;

let buttonItems: Array<{ text: string, value: number }> = [
        { text: 'No Support', value: 1 },
        { text: 'Goverment', value: 2 },
        { text: 'Parent', value: 3 }
    ];

describe('\nUnit Tests for CSTButtonGroupComponent', () => {
  describe('\n\tFor input default properties', () => {
    beforeEach(() => {
             testButtonGroup = new CSTButtonGroupComponent();
    });

  it('Id should be empty ', () => {
    expect(testButtonGroup._id).toEqual('');
  });

  it('_selection should be multiple', () => {
    expect(testButtonGroup._selection).toEqual('multiple');
  });

  it('should not be disable', () => {
    expect(testButtonGroup._disabled).toEqual(false);
  });

it('should able to set and get buttongoupItems', () => {
     testButtonGroup.buttonitems = buttonItems;
    expect(testButtonGroup.buttonitems).toEqual(buttonItems);
  });

it('should be able to set value and gets updated', () => {
    testButtonGroup.value = 123;
    expect(testButtonGroup.value).toEqual(123);
  });
 });

  describe('\n\tFor methods and functions', () => {

   beforeEach(() => {
             testButtonGroup = new CSTButtonGroupComponent();
    });

   it('should be able to set selectedValue and gets updated', () => {
    let  selectedValueArray: string[] = [];

    selectedValueArray.push('test');
    testButtonGroup.selectedValue = selectedValueArray;
    expect(testButtonGroup.selectedValue).toEqual(selectedValueArray);
  });

   it('should push single value after click event when _selection type is single', () => {
    let  actualArray: string[] = [];
    actualArray.push('testSingleSelection');
    testButtonGroup._selection = 'single';
    testButtonGroup.onClick('testSingleSelection');

    expect(actualArray).toEqual(testButtonGroup.selectedValueArray);
  });

    it('should push multiple value after click event when _selection type is multiple', () => {
    let  actualArray: string[] = [];
    actualArray.push('1');
    actualArray.push('2');
    actualArray.push('3');

    testButtonGroup.onClick('1');
    testButtonGroup.onClick('2');
    testButtonGroup.onClick('3');

    expect(actualArray).toEqual(testButtonGroup.selectedValueArray);
  });

    it('should delete value if click event is two times in  _selection type is multiple', () => {
    let  actualArray: string[] = [];
    actualArray.push('1');
    actualArray.push('3');

    testButtonGroup.onClick('1');
    testButtonGroup.onClick('2');
    testButtonGroup.onClick('3');
    testButtonGroup.onClick('2');

    expect(actualArray).toEqual(testButtonGroup.selectedValueArray);
  });

     it('should able to set button type as small', () => {

      testButtonGroup.smallButtonType = true;
      expect(testButtonGroup.buttonClass['cst-button-small']).toBe(true);

      testButtonGroup.smallButtonType = false;
      expect(testButtonGroup.buttonClass['cst-button-small'] ).toBe(false);
  });

     it('should able to set togglable buttongroup', () => {

      testButtonGroup.togglable = true;
      expect(testButtonGroup._selection ).toBe('single');

      testButtonGroup.togglable = false;
      expect(testButtonGroup._selection ).toBe('multiple');
  });

      it('should able to set isvalidate and apply CSS buttongroup', () => {

      spyOn(testButtonGroup, 'displayErrorCss').and.callFake(function() {
        return;
      });

      testButtonGroup.isvalidate = true;

      expect(testButtonGroup._isvalidate ).toBe(true);
      expect(testButtonGroup.displayErrorCss).toHaveBeenCalled();
      expect((<any>testButtonGroup).displayErrorCss.calls.count()).toBe(1);
  });

  it('should display error if isvalidation is true and no button has cliecked', () => {

      testButtonGroup._isvalidate = true;
      testButtonGroup.selectedValueArray.length = 0;

      testButtonGroup.displayErrorCss();

      expect(testButtonGroup.buttonGroupClass['cst-buttongroup-error'] ).toBe(true);
      expect(testButtonGroup.errorMsgShow ).toBe(true);

     testButtonGroup.selectedValueArray.push('2');
     testButtonGroup.displayErrorCss();

     expect(testButtonGroup.buttonGroupClass['cst-buttongroup-error'] ).toBe(false);
     expect(testButtonGroup.errorMsgShow ).toBe(false);
  });

  });
});
