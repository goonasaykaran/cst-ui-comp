import { FilterPipe } from './cst-grid.filter.pipe';

let filterPipe: FilterPipe;
let fakeFunction = function() { return; };
let gridData: Array<Object> = [{  Category: {CategoryID: 1, CategoryName: 'Beverages', Description: 'Soft drinks'},
                                  CategoryID: 1, Discontinued: false, ProductID: 1,
                                  ProductName: 'Chai', QuantityPerUnit: '120bags'},
                               { Category: {CategoryID: 2, CategoryName: 'Beverages2', Description: 'Hard drinks'},
                                  CategoryID: 2, Discontinued: false, ProductID: 2,
                                  ProductName: 'chang', QuantityPerUnit: '120bags'}];

let valueData = {data: [{ CategoryID: 1, Discontinued: false, ProductID: 1,
                         ProductName: 'Chai', QuantityPerUnit: '120bags',
                         ReorderLevel: 10, SupplierID: 1, UnitPrice: 18, UnitsInStock: 39, UnitsOnOrder: 0  }]};

 describe('\nUnit tests for method and functions', () => {

  describe('\n\tFor FilterPipe for transform  methods', () => {

  beforeEach(() => { filterPipe = new FilterPipe(); });

  it('should able to call  with no dataArray and filter', () => {
    expect(filterPipe.transform()).toEqual(undefined);
  });

  it('should call with filter string as number', () => {
    spyOn(filterPipe, 'isNumber').and.callFake(function() { return true; });
    spyOn(filterPipe, 'filterDefault').and.callThrough();

    filterPipe.transform(gridData, '1');

    expect(filterPipe.isNumber).toHaveBeenCalled();
    expect(filterPipe.filterDefault).toHaveBeenCalled();

    expect((<any>filterPipe).isNumber.calls.count()).toBe(1);
    expect((<any>filterPipe).filterDefault.calls.count()).toBe(1);
  });

  it('should call with filter string as string', () => {
    spyOn(filterPipe, 'isNumber').and.callFake(function() { return false; });
    spyOn(filterPipe, 'filterByString').and.callFake(function() { return 'test'; });
    spyOn(gridData, 'filter').and.returnValue('test');

    filterPipe.transform(gridData, 'TEST');

    expect(filterPipe.isNumber).toHaveBeenCalled();
    expect((<any>filterPipe).isNumber.calls.count()).toBe(1);

    expect(filterPipe.filterByString).toHaveBeenCalled();
    expect((<any>filterPipe).filterByString.calls.count()).toBe(1);
  });


  it('should call with filter as object', () => {
    let filter = { ProductName: 'Chai', QuantityPerUnit: '120bags'};
    spyOn(filterPipe, 'filterByObject').and.callFake(function() { return 'test'; });
    spyOn(gridData, 'filter').and.returnValue('test');

    filterPipe.transform(gridData, filter);
    expect(filterPipe.filterByObject).toHaveBeenCalled();
    expect((<any>filterPipe).filterByObject.calls.count()).toBe(1);
  });

  it('should call with filter as nither string nor object', () => {
    spyOn(filterPipe, 'filterDefault').and.callFake(function() { return 'test'; });
    spyOn(gridData, 'filter').and.returnValue('test');

    filterPipe.transform(gridData, fakeFunction);

    expect(filterPipe.filterDefault).toHaveBeenCalled();
    expect((<any>filterPipe).filterDefault.calls.count()).toBe(1);
  });

 });

 describe('\n\tFor FilterPipe for private filterDefault methods', () => {

   beforeEach(() => { filterPipe = new FilterPipe(); });

  it('should filter Default with no grid values', () => {
    expect(filterPipe.filterDefault('TestFilter')()).toEqual(false);
  });

  it('should filter Default with no grid filter', () => {
    expect(filterPipe.filterDefault()(valueData)).toEqual(true);
  });

  it('should filter Default with no grid filter and value', () => {
     expect(filterPipe.filterDefault()()).toEqual(true);
  });

  it('should filter Default with valid grid filter and value', () => {
      let filterData = {CategoryID: 1, Discontinued: false, ProductID: 1};
      expect(filterPipe.filterDefault(filterData)(valueData)).toEqual(false);
  });
});


describe('\n\tFor FilterPipe for private filterByObject methods', () => {

  let gridValuesWithObject =  { Product: {ProductID: 1, ProductName: 'Chai'}, SupplierID: 1};
  let gridValuesWithString =  {ProductID: 1, ProductName: 'Chai', SupplierID: 1};

  beforeEach(() => { filterPipe = new FilterPipe(); });

  it('should filter By Object with value not has Own Property', () => {
      let filterData = {CategoryID: 5, Discontinued: false, ProductID: 5};
      expect(filterPipe.filterByObject(filterData)(valueData)).toEqual(false);
    });

  it('should filter By Object with emplty filter object', () => {
      expect(filterPipe.filterByObject({})(gridData)).toEqual(true);
    });

  it('should filter By Object with value has Own Property with filter and value type as string', () => {
      let filterStringData = {ProductName: 'chai'};
      expect(filterPipe.filterByObject(filterStringData)(gridValuesWithString)).toEqual(true);
    });

  it('should filter By Object with value has Own Property with filter and value type as object', () => {
      let filterObjectData = {Product: {ProductName: 'Chai'}};
      expect(filterPipe.filterByObject(filterObjectData)(gridValuesWithObject)).toEqual(true);
    });

  it('should filter By Object with value has Own Property with filter and value type as function', () => {
      let filterData = {functionOne: fakeFunction};
      let gridValueData =  {functionOne: fakeFunction, functionTwo: fakeFunction};
      expect(filterPipe.filterByObject(filterData)(gridValueData)).toEqual(true);
    });

  it('should filter By Object with value has Own Property with filter and value not matches', () => {
      let invalidFilterData = {ProductName: 'coffee'};
      expect(filterPipe.filterByObject(invalidFilterData)(gridValuesWithString)).toEqual(false);
    });
 });

describe('\n\tFor FilterPipe for private filterByString methods', () => {

  beforeEach(() => { filterPipe = new FilterPipe(); });

  it('should filter string with valid grid filter and value', () => {
      expect(filterPipe.filterByString('mypro')('myProduct')).toEqual(true);
  });

  it('should not filter string with invalid grid filter and value', () => {
      expect(filterPipe.filterByString('mypro')('mycatagory')).toEqual(false);
  });

  it('should filter string with Different String Case grid filter and value', () => {
      expect(filterPipe.filterByString('MYPRO')('myProduct')).toEqual(true);
      expect(filterPipe.filterByString('mypro')('MYPRODUCT')).toEqual(true);
  });
});

describe('\n\tFor FilterPipe for private isNumber methods', () => {

  beforeEach(() => { filterPipe = new FilterPipe(); });

  it('should return true if number', () => {
      expect(filterPipe.isNumber('100')).toEqual(true);
  });

  it('should return false if not a number', () => {
      expect(filterPipe.isNumber('testNumber')).toEqual(false);
  });

 });

});
