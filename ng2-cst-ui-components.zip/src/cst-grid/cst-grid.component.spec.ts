import { Component } from '@angular/core';
import { ComponentFixture, inject, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { CSTGridComponent } from './cst-grid.component';
import * as _ from 'underscore';

  let testGrid: CSTGridComponent;

describe('\nUnit Tests for CSTGridComponent', () => {
 describe('\n\tFor input default properties', () => {
   beforeEach(() => {
             testGrid = new CSTGridComponent();
    });

  it('should be able to set and get gridData', () => {
    testGrid.gridData = 'Test_Grid_Data';
    expect(testGrid.gridData).toEqual('Test_Grid_Data');
  });

  it('should be able to set and get gridColumns', () => {
    testGrid.gridColumns = 'Test_Grid_Columns';
    expect(testGrid.gridColumns).toEqual('Test_Grid_Columns');
  });
 });

 describe('\n\tFor methods and functions', () => {
   beforeEach(() => {
             testGrid = new CSTGridComponent();
    });

  let fakeFunction = function() { return; };
  it('should able to filter the Text', () => {
      spyOn(_, 'clone').and.callFake(fakeFunction);
      let arg: number = 1;

      testGrid.filterText('text_selectFilter', arg);
      expect(_.clone).toHaveBeenCalled();
      expect((<any>_).clone.calls.count()).toBe(1);
  });

 });
});
