import { Component, Input, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

const noop: any = () => {
	// nothing here
};
export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
    provide : NG_VALUE_ACCESSOR,
    useExisting: forwardRef( () => CSTTextfieldComponent),
    multi: true
};

@Component({
    selector: 'cst-textfield',
    templateUrl: './cst-textfield.component.html',
    providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
})
export class CSTTextfieldComponent implements ControlValueAccessor {

    @Input('type') type: string = 'text';
    @Input('label') label: string;
    @Input('tooltip') tooltipMsg: string = null;
    @Input('placeholder') placeholder: string = '';
    @Input('disabled') disabled: boolean = false;
    @Input('isRequired') isRequired: boolean = false;
    @Input('showValueChange') showValueChange: boolean = false;
    @Input() errorMsg: string = 'Oops! Something is wrong...';
    validationClass: string = '';
    errorMsgShow: boolean = false;
    @Input() validation: any = {
        validation: function() {
            return true;
        },
        validationMsg: 'Oops! Something is wrong'
    };

        textFieldClass: Object = {
        'cst-textfield-error': false
    };

// Property changed from private to public
    public onTouchedCallback: () => void = noop;

    public onChangeCallback: (_: any) => void = noop;

    private innerValue: any = '';
    private previousValue: any = '';


    constructor () {
       // console.log('cst.textfield.component');
    }

    ngOnInit(): void {
		// todo
        console.log('called ngOnInit');
        console.log(this.showErrorMsg);
    }

    ngOnDestroy(): void {
  	// todo
    console.log('called ngOnDestroy');
    }

    ngAfterViewInit(): void {
		// todo
        console.log('called ngAfterViewInit');
    }

    get isValueChanged(): boolean {
       return (this.showValueChange && this.innerValue && (this.innerValue !== this.previousValue));
    }

    get value(): any {
        return this.innerValue;
    };

    set value(v: any) {
        if (v !== this.innerValue) {
            this.previousValue = this.innerValue;
            this.innerValue = v;
            this.onChangeCallback(v);
        }
    }

    onBlur(): void {
        this.onTouchedCallback();
    }

    onInput(): void {
        this.validationClass = 'validate';
    }

    @Input()
    set showErrorMsg(val: boolean) {
        this.errorMsgShow = val;
        this.textFieldClass['cst-textfield-error'] = val;
    }

    writeValue(value: any): void {
        if (value !== this.innerValue) {
            this.innerValue = value;
			// this.value=value;
        }
    }

    registerOnChange(fn: any): void {
        this.onChangeCallback = fn;
    }

    registerOnTouched(fn: any): void {
        this.onTouchedCallback = fn;
    }

    validationFunction(val): void {
        if (this.validation && !this.validation.validation(val)) {
            this.errorMsg = this.validation.validationMsg;
            this.showErrorMsg = this.validation.validation;
        }
    }
}
