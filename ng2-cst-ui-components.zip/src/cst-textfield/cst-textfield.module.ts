import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { CSTTextfieldComponent } from './cst-textfield.component';
import { CSTTooltipModule } from '../cst-tooltip/cst-tooltip.module';

@NgModule({
  imports: [CommonModule, CSTTooltipModule, BrowserModule, FormsModule],
  declarations: [CSTTextfieldComponent],
  exports: [CSTTextfieldComponent]
})
export class CSTTextfieldModule {
  public static forRoot(): ModuleWithProviders {return {ngModule: CSTTextfieldModule, providers: []}; }
}
