import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';

import { CSTDatePickerComponent } from './cst-datepicker.component';

import { IntlModule } from '@progress/kendo-angular-intl';

import { DateInputsModule } from '@progress/kendo-angular-dateinputs';

import { CalendarModule } from '@progress/kendo-angular-dateinputs';

@NgModule({
  imports: [CommonModule, IntlModule, DateInputsModule, CalendarModule],
  declarations: [CSTDatePickerComponent],
  exports: [CSTDatePickerComponent]
})
export class CSTDatePickerModule {
  public static forRoot(): ModuleWithProviders {return {ngModule: CSTDatePickerModule, providers: []};
};
}
