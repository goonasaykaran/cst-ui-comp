import {
    Component,
    Input,
    ChangeDetectionStrategy
} from '@angular/core';



@Component({
    selector: 'cst-datepicker',
    templateUrl: './cst-datepicker.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class CSTDatePickerComponent {

 @Input('value') _value: any = null;

 @Input('focusedDate') _focusedDate: Date;

  get value(): any {
        return this._value;
   };

    set value(v: any) {
        this._value = v;
    }

  get focusedDate(): Date {
        return this._focusedDate;
  };
}
