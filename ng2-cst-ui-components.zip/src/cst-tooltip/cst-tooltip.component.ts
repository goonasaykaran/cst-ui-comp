import { Component, Input } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';
/*
 * We're loading this component asynchronously
 * We are using some magic with es6-promise-loader that will wrap the module with a Promise
 * see https://github.com/gdi2290/es6-promise-loader for more info
 */


@Component({
    selector: 'cst-tooltip',
    templateUrl: './cst-tooltip.component.html'
})

export class CSTTooltipComponent {
    public _message: string = '';
    showToolTip: boolean = true;
    toolTipClass: string = 'display-none';
    @Input()
    set tooltip(newval: string) {
        this._message = newval;
    }

    get tooltip(): string {
        return this._message;
    }

    @Input()
    set tooltipType(newval: any) {
        this._tooltipType = newval;
    }
    _tooltipType: string = 'medium';

    constructor() {
		// constructor
    }

    ngOnInit(): void {
        console.log('Init::' + this._message);
		// todo
    }

    onClickToolTip(event: any): void {
		// toogle tooltip
        this.toolTipClass = this.showToolTip ? 'display-block' : 'display-none';
        this.showToolTip = !this.showToolTip;
    }
}
