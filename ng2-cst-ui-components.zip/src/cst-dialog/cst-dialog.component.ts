import { Component, Input } from '@angular/core';

@Component({
    selector: 'cst-dialog',
    templateUrl: './cst-dialog.component.html'
})

export class CSTDialog {
    @Input() title: string = 'Dialog Title';
    @Input() buttons: Array<Object> = [];
    @Input() visible: boolean = false;

    buttonsAvailable(): boolean {
        return this.buttons.length > 0;
    }
}
