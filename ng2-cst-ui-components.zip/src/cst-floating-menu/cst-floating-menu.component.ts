import {
    Component,
    Input,
    HostListener,
    ElementRef,
    Inject
} from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { PageScrollConfig, PageScrollInstance, PageScrollService } from 'ng2-page-scroll';

@Component({
    selector: 'cst-floating-menu',
    templateUrl: './cst-floating-menu.component.html'
})

export class CSTFloatingMenuComponent {
/* tslint:disable */

	childView: any;
	isStandalone: boolean = true;
	clickedOnMenu: boolean = false;
	@Input() parentElementId: any;
	@Input() menuItems: any;
	@Input() pageScrollOffset: number = 50;
	@Input() position: string = 'bottom-right';

	constructor(
		private element: ElementRef,
		private pageScrollService: PageScrollService,
		@Inject(DOCUMENT) private document: any) {}

	ngOnInit(): void {
		this.setUpPageScrollConfig();
		this.menuItems = this.menuItems.map(subMenu => this.addClassPropertiesToSubMenu(subMenu));
		// this.isStandalone =  window.ENVIRONMENT.rootAppName ? true : false;
		this.isStandalone = true;
	}

	ngAfterViewInit():  void {
		if (!this.isStandalone) {
			this.childView = this.document.getElementById('sg-portal-view-workspace-app-content');
		}
	}

	@HostListener('window:mousewheel', ['$event'])
	highlightMenuBaseOnScrollPosition(event: any): void {
		this.highlightSubMenuOnScroll();
	}

	@HostListener('window:keydown', ['$event'])
	hightlightMenuBaseOnUpAndDownKeys(event: any): void {
		if (event.keyCode === 40 || event.keyCode === 38) {
			this.highlightSubMenuOnScroll();
		}
	}

	@HostListener('document:click', ['$event.target'])
	checkClickPosition(targetElement: any): void {
		const checkIfClickInElement: any = this.element.nativeElement.contains(targetElement);
		if (!checkIfClickInElement) { this.closeMenu(); }
	}

	subButtonClass: any = {
		'showMenu': false,
		'hideMenu': true
	};
	mainButtonClass: any = {
		'is-active': false
	};
	iconsClass: any = {
		success: false,
		error: false,
		warning: false
	};

	closeMenu(): void {
		this.subButtonClass.showMenu = false;
		this.subButtonClass.hideMenu = true;
		this.mainButtonClass['is-active'] = false;
	}

	toggleMenuState(): void {
		this.toggleMainButtonClass();
		this.toggleSubButtonClass();
	}

	onClickMenuItem(menuItem: any): void {
		if (menuItem.action) {
			menuItem.action();
		}
		if (menuItem.target) {
			this.scrollToSection(menuItem.target);
		}
		this.removeAllFocusAndFocusOne(menuItem);
	}

	highlightSubMenuOnScroll(): void {
		this.menuItems
		.filter(item => item.target)
		.forEach(item => {
			const element: any = document.querySelector(item.target).getBoundingClientRect();
			if ((element.top - this.pageScrollOffset - 50) < 0) {
				this.removeAllFocusAndFocusOne(item);
			}
		});
	}

	toggleMainButtonClass(): void {
		this.mainButtonClass['is-active'] = !this.mainButtonClass['is-active'];
	}

	toggleSubButtonClass(): void {
		this.subButtonClass.showMenu = !this.subButtonClass.showMenu;
		this.subButtonClass.hideMenu = !this.subButtonClass.hideMenu;
	}

	setUpPageScrollConfig(): void {
		PageScrollConfig.defaultDuration = 500;
		PageScrollConfig.defaultScrollOffset = this.pageScrollOffset;
		PageScrollConfig.defaultEasingLogic = {
			ease: this.scrollEaseLogic
		};
	}

	scrollToSection(elementId: string): void {
		let pageScrollInstance: PageScrollInstance;
		if (this.isStandalone) {
			pageScrollInstance = PageScrollInstance.simpleInstance(this.document, elementId);
		} else {
			pageScrollInstance = PageScrollInstance.simpleInlineInstance(this.document, elementId, this.childView);
		}
		this.pageScrollService.start(pageScrollInstance);
	}

	addClassPropertiesToSubMenu(menuItem: any): Object {
		const addtionalStyleProperties: Object = {
			styleClass: {
				'title-focus': false
			},
			iconStyles: this.iconsClass
		};
		return Object.assign({}, addtionalStyleProperties, menuItem);
	}

	removeAllFocusAndFocusOne(menuItem: any): void {
		this.menuItems.map(subMenu => {
			subMenu.styleClass['title-focus'] = false;
			return subMenu;
		});
		menuItem.styleClass['title-focus'] = true;
	}

	showAndHideIcon(menuItem: any): boolean {
		for (let iconStyle in menuItem.iconStyles) {
			if (menuItem.iconStyles[iconStyle]) { return true; };
		}
		return false;
	}

	// snippets taken from ng2-page-scroll
	scrollEaseLogic(currentTime: number, beginningValue: number, changeInValue: number, duration: number): number {
        if (currentTime === 0) { return beginningValue; }
        if (currentTime === duration) { return beginningValue + changeInValue; }
       	currentTime /= duration / 2;
        if (currentTime < 1) { return changeInValue / 2 * Math.pow(2, 10 * (currentTime - 1)) + beginningValue; }
        return changeInValue / 2 * (-Math.pow(2, -10 * --currentTime) + 2) + beginningValue;
	}
/* tslint:enable */
}
