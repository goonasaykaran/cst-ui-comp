import { Component, Input, HostListener, ElementRef, Inject } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { CSTFloatingMenuComponent } from './cst-floating-menu.component';
import { PageScrollConfig, PageScrollInstance, PageScrollService } from 'ng2-page-scroll';


let floatingMenu: CSTFloatingMenuComponent;

let state: Array<Object> = [{name: 'Buttons', target: '#buttons', action: () => console.log('hi'), iconStyles: {success: true}  },
              {name: 'Radio',  target: '#radio', iconStyles: {  error: true  } },
              {name: 'Step Slider', target: '#step-slider', iconStyles: {warning: true}},
              {name: 'Checkboxes', target: '#checkbox'}];

let offSetValue: number = 50;

 beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ CSTFloatingMenuComponent ]
    });
    floatingMenu = new CSTFloatingMenuComponent(null, null, null);
  });

describe('\nUnit Tests for CSTFloatingMenuComponent', () => {

describe('\n\tFor Input default properties', () => {

  it('isStandalone should be true', () => {
    expect(floatingMenu.isStandalone).toBe(true);
  });

  it('clickedOnMenu should be false', () => {
     expect(floatingMenu.clickedOnMenu).toBe(false);
  });

  it('pageScrollOffset should be 50 ', () => {
    expect(floatingMenu.pageScrollOffset).toEqual(50);
  });

  it('should be at bottom-right position', () => {
    expect(floatingMenu.position).toEqual('bottom-right');
  });

});


describe('\n\t For methods and functions', () => {

it('initial state of sub button should be not be active', () => {   // @Hamzeen
    expect(floatingMenu.subButtonClass.showMenu).toBeFalsy();
    expect(floatingMenu.subButtonClass.hideMenu).toBeTruthy();
  });

it('initial state of main button should be not active', () => {    // @Hamzeen
    expect(floatingMenu.mainButtonClass['is-active']).toBeFalsy();
  });

it('should have Initial state of iconsClass', () => {
    expect(floatingMenu.iconsClass.success).toBeFalsy();
    expect(floatingMenu.iconsClass.error).toBeFalsy();
    expect(floatingMenu.iconsClass.warning).toBeFalsy();
  });

it('should be able to closeMenu()', () => {
    floatingMenu.closeMenu();

     expect(floatingMenu.subButtonClass.showMenu).toBeFalsy();
    expect(floatingMenu.subButtonClass.hideMenu).toBeTruthy();
    expect(floatingMenu.mainButtonClass['is-active']).toBeFalsy();
  });

it('should call toggleMainButtonClass if toggleMenuState() is invoked', () => {
     spyOn(floatingMenu, 'toggleMainButtonClass').and.callFake(function() {
          return;
       });

       floatingMenu.toggleMenuState();
      expect(floatingMenu.toggleMainButtonClass).toHaveBeenCalled();
      expect((<any>floatingMenu).toggleMainButtonClass.calls.count()).toBe(1);
  });

it('should call toggleSubButtonClass if toggleMenuState() is invoked', () => {

    spyOn(floatingMenu, 'toggleSubButtonClass').and.callFake(function() {
      return;
    });
    floatingMenu.toggleMenuState();
    expect(floatingMenu.toggleSubButtonClass).toHaveBeenCalled();
    expect((<any>floatingMenu).toggleSubButtonClass.calls.count()).toBe(1);

  });

it('toggle should change state of main button to active', () => {
    floatingMenu.toggleMenuState();
    expect(floatingMenu.mainButtonClass['is-active']).toBeTruthy();
  });

it('toggle should change state of sub button to active', () => {
    floatingMenu.toggleMenuState();
    expect(floatingMenu.subButtonClass.showMenu).toBeTruthy();
    expect(floatingMenu.subButtonClass.hideMenu).toBeFalsy();
  });

it('should removeAllFocus onClickMenuItem() method call ', () => {

    spyOn(floatingMenu, 'removeAllFocusAndFocusOne');
    floatingMenu.onClickMenuItem('anyFakeObject');
    expect(floatingMenu.removeAllFocusAndFocusOne).toHaveBeenCalled();
    expect((<any>floatingMenu).removeAllFocusAndFocusOne.calls.count()).toBe(1);
  });

it('Should scrollToSection onClickMenuItem() method call', () => {
   spyOn(floatingMenu, 'scrollToSection');
   spyOn(floatingMenu, 'removeAllFocusAndFocusOne');


    floatingMenu.onClickMenuItem(state[1]);
    expect(floatingMenu.scrollToSection).toHaveBeenCalled();
    expect((<any>floatingMenu).scrollToSection.calls.count()).toBe(1);
    expect(floatingMenu.removeAllFocusAndFocusOne).toHaveBeenCalled();
    expect((<any>floatingMenu).removeAllFocusAndFocusOne.calls.count()).toBe(1);
  });

it('Should perform menuItem.action and scrollToSection onClickMenuItem() method call', () => {

    spyOn(floatingMenu, 'scrollToSection');
    spyOn(floatingMenu, 'removeAllFocusAndFocusOne');
    spyOn(console, 'log');

    floatingMenu.onClickMenuItem(state[0]);

    expect(console.log).toHaveBeenCalled();
    expect((<any>console).log.calls.count()).toBe(1);
    expect(floatingMenu.scrollToSection).toHaveBeenCalled();
    expect((<any>floatingMenu).scrollToSection.calls.count()).toBe(1);
    expect(floatingMenu.removeAllFocusAndFocusOne).toHaveBeenCalled();
    expect((<any>floatingMenu).removeAllFocusAndFocusOne.calls.count()).toBe(1);
  });

it('Should setUp PageScrollConfig', () => {

    floatingMenu.setUpPageScrollConfig();

    expect(PageScrollConfig.defaultDuration).toEqual(500);
    expect(PageScrollConfig.defaultScrollOffset).toEqual(50);
  });

it('Should scroll EaseLogic', () => {

    // Returns beginning value 
    expect(floatingMenu.scrollEaseLogic(0, 5, 3, 4)).toEqual(5);
    // currentTime === duration
    expect(floatingMenu.scrollEaseLogic(4, 5, 3, 4)).toEqual(8);
    // currentTime < 1
    expect(floatingMenu.scrollEaseLogic(0.5, 1, 2, 3)).toEqual(1.0098431332023037);
    expect(floatingMenu.scrollEaseLogic(4, 5, 3, 5)).toEqual(7.9765625);
  });

it('Should addClass Properties To SubMenu', () => {

   let subMenuObjectToAddClassProperties: Object = {name: 'Radio', target: '#radio', iconStyles: {'error': true}};
   let expectedObject: Object = {styleClass: {'title-focus': false}, iconStyles: {'error': true}, name: 'Radio', target: '#radio'};

   expect(floatingMenu.addClassPropertiesToSubMenu(subMenuObjectToAddClassProperties)).toEqual(expectedObject);
  });

it('Should removeAllFocus and FocusOne', () => {

   let menuItems: Array<Object> = [{name: 'Buttons', target: '#buttons', action: () => console.log('hi'), iconStyles: {success: true}, 'styleClass': {'title-focus': false}  },
              {name: 'Radio',  target: '#radio', iconStyles: {  error: true  }, styleClass: {'title-focus': false}},
              {name: 'Step Slider', target: '#step-slider', iconStyles: {warning: true}, styleClass: {'title-focus': false}},
              {name: 'Checkboxes', target: '#checkbox', styleClass: { 'title-focus': false }}];

       floatingMenu.menuItems = menuItems;
       let singleMenuItem: Object = menuItems[2];
       floatingMenu.removeAllFocusAndFocusOne(singleMenuItem);
       expect((<any>singleMenuItem).styleClass['title-focus']).toBe(true);
  });

it('Should ngOnInit', () => {

    spyOn(floatingMenu, 'setUpPageScrollConfig');
    spyOn(floatingMenu, 'addClassPropertiesToSubMenu');

    floatingMenu.menuItems = state;
    floatingMenu.ngOnInit();

     expect(floatingMenu.setUpPageScrollConfig).toHaveBeenCalled();
     expect(floatingMenu.addClassPropertiesToSubMenu).toHaveBeenCalled();
     expect((<any>floatingMenu).setUpPageScrollConfig.calls.count()).toBe(1);
     expect((<any>floatingMenu).addClassPropertiesToSubMenu.calls.count()).toBe(4);
     expect(floatingMenu.isStandalone).toBeTruthy;
  });

 });
});
