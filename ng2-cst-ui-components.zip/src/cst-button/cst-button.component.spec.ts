import { Component } from '@angular/core';
import { ComponentFixture, inject, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { CSTButtonComponent } from './cst-button.component';

  let testButton: CSTButtonComponent;

 describe('\nUnit Tests for CSTButtonComponent', () => {
 describe('\n\tFor input default properties', () => {
    beforeEach(() => {
             testButton = new CSTButtonComponent();
    });

  it('Id should be empty ', () => {
    expect(testButton._id).toEqual('');
  });

  it('should have defined CSTButtonComponent', () => {
    expect(testButton).toBeDefined();
  });

  it('should be able to set and get value', () => {
  testButton._id = 'Test_ID';
  expect(testButton._id).toEqual('Test_ID');
  });

  it('should be able to set and get button name', () => {
  testButton._name = 'Primary';
  expect(testButton._name).toEqual('Primary');
  });

  it('should be able to set and get button class', () => {
  testButton._class = 'CSTButton';
  expect(testButton._class).toEqual('CSTButton');
  });

  it('should be enabled', () => {
  expect(testButton._disabled).toEqual(false);
  });

  it('should not be primary by default', () => {
  expect(testButton._primary).toEqual(false);
  });

  it('should have ButtonIcon value', () => {
  testButton._icon = 'ButtonIcon';
  expect(testButton._icon).toEqual('ButtonIcon');
  });

  it('should be able to get and set ButtonIconClass', () => {
  testButton._iconClass = 'ButtonIconClass';
  expect(testButton._iconClass).toEqual('ButtonIconClass');
  });

  it('should be able to get and set imageUrl', () => {
  testButton._imageUrl = 'C:/myimages/imageUrl_01';
  expect(testButton._imageUrl).toEqual('C:/myimages/imageUrl_01');
  });

  it('should have _togglable false', () => {
    expect(testButton._togglable).toEqual(false);
  });

  it('should be able to get and set Submit button value', () => {
    testButton._value  = 'Submit';
    expect(testButton._value).toEqual('Submit');
  });
});


describe('\n\tFor methods and functions', () => {

    beforeEach(() => {
       testButton = new CSTButtonComponent();
    });

  it('should log console message on init', () => {
   spyOn(console, 'log');

   testButton.ngOnInit(); // invokes the method to be tested
   // verifications
   expect(console.log).toHaveBeenCalled();
   expect((<any>console).log.calls.count()).toBe(1);

  });

  it('should have buttonType false by default', () => {
      testButton.buttonType = false;
      expect(testButton.buttonClass['cst-button-small']).toEqual(false);
  });

  it('should be able to set buttonType to true', () => {
      testButton.buttonType = true;
      testButton.buttonClass['cst-button-small'] = true;
      expect(testButton.buttonClass['cst-button-small']).toEqual(true);
  });

  it('should be able to set button alignment to left', () => {
      testButton.align = 'left';
      testButton.buttonClass['cst-button-align-right'] = false;
      expect(testButton.buttonClass['cst-button-align-left']).toEqual(true);
      expect(testButton.buttonClass['cst-button-align-right']).toEqual(false);
  });

  it('should be able to set button alignment to right', () => {
      testButton.align = 'right';
      expect(testButton.buttonClass['cst-button-align-left']).toEqual(false);
      expect(testButton.buttonClass['cst-button-align-right']).toEqual(true);
  });
});
});

