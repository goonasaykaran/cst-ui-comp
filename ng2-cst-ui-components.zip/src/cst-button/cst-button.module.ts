import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';

import { CSTButtonComponent } from './cst-button.component';
import { ButtonsModule } from '@progress/kendo-angular-buttons';

@NgModule({
  imports: [CommonModule, ButtonsModule],
  declarations: [CSTButtonComponent],
  exports: [CSTButtonComponent]
})
export class CSTButtonModule {
  public static forRoot(): ModuleWithProviders {return {ngModule: CSTButtonModule, providers: []};
};
}

