import { Component, Input, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, FormsModule, ReactiveFormsModule, FormGroup, FormControl }from '@angular/forms';


export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
    provide : NG_VALUE_ACCESSOR,
    useExisting: forwardRef( () => CSTMultiselectComponent),
    multi: true
};

@Component({
    selector: 'cst-multiselect',
    templateUrl: './cst-multiselect.component.html',
    providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
})

export class CSTMultiselectComponent {

    @Input('data') _data: any;

    @Input('value') _value: any = null;

    @Input('textField') _textField: any = null;

    @Input('valueField') _valueField: any = null;

    @Input('valuePrimitive') _valuePrimitive: boolean = true;

    get value(): any {
        return this._value;
    };

    set value(v: any) {
        this._value = v;
    }
}
