import { Component, Input, forwardRef, Output, EventEmitter } from '@angular/core';
import { ComponentFixture, inject, TestBed, fakeAsync, tick, getTestBed, async }from '@angular/core/testing';
import { CSTMultiselectComponent } from './cst-multiselect.component';

let multiselect: CSTMultiselectComponent;

let listItemsData: Array<{ text: string, value: number }> = [
        { text: 'Small', value: 1 },
        { text: 'Medium', value: 2 },
        { text: 'Large', value: 3 }
    ];
describe('\nUnit Test for CSTMultiselectComponent', () => {
describe('\n\tFor default Input properties', () => {

  beforeEach(async(() => {
      multiselect = new CSTMultiselectComponent();
    }));

 it('should be able to set value and gets updated', () => {
    // invokes the setter method of value
    multiselect.value = 'testValue';
    // verifies the value using the getter method of value
    expect(multiselect.value).toEqual('testValue');
  });

  it('should be able to set and gets data', () => {
    multiselect._data = listItemsData;
    expect( multiselect._data).toEqual(listItemsData);
  });

  it('should be able to set and gets textField', () => {
    multiselect._textField = 'textFieldData';
    expect( multiselect._textField).toEqual('textFieldData');
  });

  it('should be able to set and gets valueField', () => {
    multiselect._valueField = 'valueFieldData';
    expect( multiselect._valueField).toEqual('valueFieldData');
  });

  it('should be able to set and gets valuePrimitive', () => {
    multiselect._valueField = false;
    expect( multiselect._valueField).toEqual(false);
  });

  });
});
